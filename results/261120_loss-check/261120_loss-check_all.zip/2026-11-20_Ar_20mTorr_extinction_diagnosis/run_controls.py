#!/usr/bin/env python3
"""Independent five-RF diagnostic branches; never alter production data."""
import concurrent.futures
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / '2026-11-19_Ar_20mTorr_100-250-300V_13.56MHz_25mm_topRF'
SEED = 20261120
PRESSURE_BASELINE = 10.0 / (101325.0 / 760000.0)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def checkpoint(voltage, cycle):
    if cycle == 0:
        return OLD / 'reflected_initial_cycle0.bin'
    return (OLD / f'2026-11-19_Ar_20mTorr_{voltage}V_13.56MHz_25mm_topRF'
            / 'warmup' / f'cycle{cycle-49:06d}-{cycle:06d}' / 'picdata.bin')

CASES = [
    ('20mTorr_250V_from0', 20.0, 250, 0),
    ('75.006mTorr_250V_from0', PRESSURE_BASELINE, 250, 0),
    ('20mTorr_300V_from200', 20.0, 300, 200),
    ('20mTorr_250V_from200', 20.0, 250, 200),
    ('20mTorr_100V_from400', 20.0, 100, 400),
]

def run(case):
    name, pressure, voltage, cycle = case
    directory = ROOT / 'controls' / name
    if directory.exists():
        raise RuntimeError(f'Refusing to overwrite diagnostic directory: {directory}')
    directory.mkdir(parents=True)
    source = ROOT / 'diagnostic.cc'
    command = ['g++', '-std=c++11', '-O3', '-march=native',
               f'-DEDUPIC_VOLTAGE_V={voltage}.0',
               f'-DEDUPIC_PRESSURE_MTORR={pressure:.17g}',
               str(source), '-o', str(directory / 'solver')]
    subprocess.run(command, check=True, capture_output=True, text=True)
    initial = checkpoint(voltage, cycle)
    shutil.copy2(initial, directory / 'input_picdata.bin')
    shutil.copy2(initial, directory / 'picdata.bin')
    metadata = {'case': name, 'pressure_mTorr': pressure,
                'pressure_Pa': pressure * 101325.0 / 760000.0,
                'voltage_peak_V': voltage, 'start_cycle': cycle, 'rf_cycles': 5,
                'rng_seed': SEED, 'input_source': str(initial),
                'input_sha256': sha(initial), 'source_sha256': sha(source),
                'compile_command': command, 'run_command': ['./solver', '5', 'm'],
                'status': 'running'}
    (directory / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
    start = time.monotonic()
    with (directory / 'run.log').open('w') as log:
        result = subprocess.run([str(directory / 'solver'), '5', 'm'], cwd=directory,
                                env={**os.environ, 'EDUPIC_DIAGNOSTIC_SEED': str(SEED)},
                                stdout=log, stderr=subprocess.STDOUT)
    metadata['elapsed_seconds'] = time.monotonic() - start
    metadata['exit_code'] = result.returncode
    if result.returncode:
        metadata['status'] = 'failed'
    else:
        rows = list(csv.DictReader((directory / 'particle_balance.csv').open()))
        assert len(rows) == 5
        residuals = []
        for row in rows:
            for species in ('e', 'i'):
                residual = (int(row[f'end_{species}']) - int(row[f'start_{species}'])
                            - int(row['ionizations'])
                            + int(row[f'{species}_loss_lower'])
                            + int(row[f'{species}_loss_upper']))
                residuals.append(residual)
        assert all(r == 0 for r in residuals), residuals
        metadata['all_particle_balance_residuals_zero'] = True
        metadata['end_checkpoint_sha256'] = sha(directory / 'picdata.bin')
        metadata['status'] = 'completed'
    (directory / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
    print(json.dumps(metadata), flush=True)
    return metadata

if __name__ == '__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        results = list(executor.map(run, CASES))
    (ROOT / 'controls_summary.json').write_text(json.dumps(results, indent=2) + '\n')
    if any(r['status'] != 'completed' for r in results):
        raise SystemExit(1)
