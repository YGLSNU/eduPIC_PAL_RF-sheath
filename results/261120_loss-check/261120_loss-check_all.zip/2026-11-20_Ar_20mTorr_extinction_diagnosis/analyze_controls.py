#!/usr/bin/env python3
"""Summarize direct event counts and discrete particle field work."""
import csv
import json
import os
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR', '/tmp/edupic-diagnosis-matplotlib')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / '2026-11-19_Ar_20mTorr_100-250-300V_13.56MHz_25mm_topRF'
Q = 1.60217662e-19
ME = 9.10938356e-31
MI = 6.63352090e-26
W = 70000.0
F = 13.56e6
VOLUME = 1e-4 * .025

def state(path):
    a = np.fromfile(path, dtype='<f8')
    ne = int(a[2]); j = 3 + 4 * ne; ni = int(a[j])
    assert len(a) == 4 + 4 * (ne + ni)
    e = a[3:j].reshape(4, ne)
    i = a[j+1:].reshape(4, ni)
    return {'cycle': int(a[1]), 'ne': ne, 'ni': ni,
            'ke': .5 * ME * W * np.square(e[1:]).sum(),
            'ki': .5 * MI * W * np.square(i[1:]).sum()}

def main():
    output = []
    for directory in sorted((ROOT / 'controls').iterdir()):
        meta = json.loads((directory / 'metadata.json').read_text())
        assert meta['status'] == 'completed'
        rows = list(csv.DictReader((directory / 'particle_balance.csv').open()))
        initial = state(directory / 'input_picdata.bin')
        final = state(directory / 'picdata.bin')
        total = lambda k: sum(float(row[k]) for row in rows)
        birth = int(total('ionizations'))
        exc = int(total('excitations'))
        le = int(total('e_loss_lower') + total('e_loss_upper'))
        li = int(total('i_loss_lower') + total('i_loss_upper'))
        assert final['ne'] - initial['ne'] == birth - le
        assert final['ni'] - initial['ni'] == birth - li
        ke_change = final['ke'] - initial['ke']
        we = total('e_field_work_J'); ew = total('e_wall_energy_J')
        wi = total('i_field_work_J')
        r = {'case': directory.name, 'pressure_mTorr': meta['pressure_mTorr'],
             'voltage_peak_V': meta['voltage_peak_V'],
             'first_RF_cycle': initial['cycle'] + 1, 'last_RF_cycle': final['cycle'],
             'rf_cycles': len(rows), 'initial_e': initial['ne'], 'initial_i': initial['ni'],
             'final_e': final['ne'], 'final_i': final['ni'],
             'ionization_pairs': birth, 'excitations': exc, 'e_wall_losses': le,
             'i_wall_losses': li, 'pair_births_per_e_wall_loss': birth / le,
             'delta_e': final['ne'] - initial['ne'], 'delta_i': final['ni'] - initial['ni'],
             'delta_e_percent': 100 * (final['ne'] / initial['ne'] - 1),
             'mean_e_field_work_W_m3': we * F / len(rows) / VOLUME,
             'mean_i_field_work_W_m3': wi * F / len(rows) / VOLUME,
             'e_field_work_J': we, 'e_wall_energy_J': ew,
             'e_kinetic_change_J': ke_change,
             'e_collisional_energy_loss_inferred_J': we - ew - ke_change,
             'excitation_ionization_threshold_energy_J': (exc * 11.5 + birth * 15.8) * Q * W,
             'initial_full_volume_e_mean_energy_eV': initial['ke'] / (initial['ne'] * W * Q),
             'final_full_volume_e_mean_energy_eV': final['ke'] / (final['ne'] * W * Q),
             'e_wall_mean_energy_eV': ew / (le * W * Q),
             'particle_balance_e_residual': final['ne'] - initial['ne'] - birth + le,
             'particle_balance_i_residual': final['ni'] - initial['ni'] - birth + li}
        info = (directory / 'info.txt').read_text()
        r['native_stability_flags_passed'] = 'CONDITION(S) VIOLATED' not in info
        for file in directory.glob('*.dat'):
            values = np.loadtxt(file)
            assert np.isfinite(values).all(), file
        r['all_native_dat_finite'] = True
        output.append(r)
    (ROOT / 'balance_summary.json').write_text(json.dumps(output, indent=2) + '\n')
    with (ROOT / 'balance_summary.csv').open('w') as f:
        writer = csv.DictWriter(f, fieldnames=list(output[0]), lineterminator='\n'); writer.writeheader(); writer.writerows(output)
    by_name = {r['case']: r for r in output}
    plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})
    fig, axs = plt.subplots(1, 3, figsize=(16, 4.8), layout='constrained')
    labels = ['75 mTorr\n250 V\nRF 1–5', '20 mTorr\n250 V\nRF 1–5',
              '20 mTorr\n100 V\nRF 401–405', '20 mTorr\n250 V\nRF 201–205',
              '20 mTorr\n300 V\nRF 201–205']
    names = ['75.006mTorr_250V_from0', '20mTorr_250V_from0',
             '20mTorr_100V_from400', '20mTorr_250V_from200', '20mTorr_300V_from200']
    ratios = [by_name[n]['pair_births_per_e_wall_loss'] for n in names]
    bars = axs[0].bar(range(5), ratios, color=['#228877','#cc6677','#4477aa','#ee9933','#aa4477'])
    axs[0].set_xticks(range(5), labels, fontsize=8)
    axs[0].axhline(1, color='black', ls='--', lw=1)
    axs[0].set_ylim(0, 1.16)
    for bar, ratio in zip(bars, ratios):
        axs[0].text(bar.get_x()+bar.get_width()/2, ratio+.025, f'{ratio:.1%}', ha='center', fontsize=9)
    axs[0].set_ylabel('Ionization births / electron wall losses')
    axs[0].set_title('(a) Direct event balance, 5 RF cycles')
    for name, color, label in [(names[0], '#228877', '75.006 mTorr'), (names[1], '#cc6677', '20 mTorr')]:
        a = np.genfromtxt(ROOT/'controls'/name/'particle_balance.csv', delimiter=',', names=True)
        initial = by_name[name]['initial_e']
        axs[1].plot(np.r_[0,a['RF_cycle']], 100*(np.r_[initial,a['end_e']]/initial-1), 'o-', color=color, label=label)
    axs[1].set(xlabel='RF cycles after identical restart', ylabel='Electron count change (%)', title='(b) Pressure-only control at 250 V')
    axs[1].legend(frameon=False)
    for voltage, color in [(100,'#4477aa'),(250,'#ee9933'),(300,'#aa4477')]:
        history = OLD/f'2026-11-19_Ar_20mTorr_{voltage}V_13.56MHz_25mm_topRF'/'history.dat'
        if not history.exists():
            history = ROOT/'original_histories'/f'{voltage}V_history.dat'
        a = np.loadtxt(history)
        nonzero = a[:,1] > 0
        axs[2].semilogy(a[nonzero,0], a[nonzero,1], color=color, label=f'{voltage} V peak')
        extinct = int(a[np.flatnonzero(~nonzero)[0],0])
        axs[2].axvline(extinct, color=color, lw=.7, ls=':')
    axs[2].set(xlabel='RF cycles, original 20 mTorr runs', ylabel='Electron macroparticles (log scale)', title='(c) Original decay before extinction')
    axs[2].legend(frameon=False)
    for ax in axs:
        ax.grid(axis='y', alpha=.15)
    fig.suptitle('Ar, 13.56 MHz, 25 mm; upper electrode powered; absorbing material surfaces\nShort branches diagnose transient balance, not steady-state convergence.', fontsize=11)
    fig.savefig(ROOT/'extinction_diagnosis.png', dpi=180)
    fig.savefig(ROOT/'extinction_diagnosis.pdf')
    plt.close(fig)
    for r in output:
        print(r['case'], 'births/loss', r['ionization_pairs'], r['e_wall_losses'],
              'ratio',round(r['pair_births_per_e_wall_loss'],5), 'deltaN%',round(r['delta_e_percent'],3),
              'Pe_W_m3',round(r['mean_e_field_work_W_m3'],2),
              'Pi_W_m3',round(r['mean_i_field_work_W_m3'],2),
              'mean_E_initial_final',round(r['initial_full_volume_e_mean_energy_eV'],3),
              round(r['final_full_volume_e_mean_energy_eV'],3))

if __name__ == '__main__':
    main()
