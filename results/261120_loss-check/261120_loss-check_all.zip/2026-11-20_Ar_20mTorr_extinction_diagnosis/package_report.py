#!/usr/bin/env python3
"""Build the dated diagnostic artifact without changing previous results."""
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / '2026-11-19_Ar_20mTorr_100-250-300V_13.56MHz_25mm_topRF'
REPO = Path('/workspace/eduPIC_PAL_RF-sheath')
TARGET = Path('/workspace/edupic-results-upload/results') / ROOT.name
EXPECTED_SOURCE = '6b86a4a5b071d0d7eaf46cea42cb82e3f797494978bd7ff488276bc64ebc6531'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    production = (REPO/'C/eduPIC.cc').read_bytes()
    assert sha(production) == EXPECTED_SOURCE
    (ROOT/'production_source.cc').write_bytes(production)
    diff = ''.join(difflib.unified_diff(production.decode().splitlines(True),
                    (ROOT/'diagnostic.cc').read_text().splitlines(True),
                    fromfile='a/C/eduPIC.cc', tofile='b/C/eduPIC.cc'))
    (ROOT/'diagnostic.patch').write_text(diff)
    histories = ROOT/'original_histories'
    histories.mkdir(exist_ok=True)
    for voltage in (100,250,300):
        shutil.copy2(OLD/f'2026-11-19_Ar_20mTorr_{voltage}V_13.56MHz_25mm_topRF'/'history.dat',
                     histories/f'{voltage}V_history.dat')
    shutil.copy2(OLD/'2026-11-19_Ar_20mTorr_300V_13.56MHz_25mm_topRF'/'warmup'/'cycle000251-000300'/'picdata.bin',
                 ROOT/'instrumentation_input_cycle300.bin')
    files = {}
    def add(path, relative=None):
        relative = relative or str(path.relative_to(ROOT))
        files[relative] = path
    for name in ['README.md','LICENSE','diagnostic.cc','seeded_control.cc','production_source.cc',
                 'diagnostic.patch','run_controls.py','analyze_controls.py','package_report.py',
                 'provenance.json','instrumentation_verification.json','controls_summary.json',
                 'balance_summary.csv','balance_summary.json','extinction_diagnosis.png',
                 'extinction_diagnosis.pdf','instrumentation_input_cycle300.bin']:
        add(ROOT/name)
    for path in (ROOT/'controls').rglob('*'):
        if path.is_file() and path.name != 'solver':
            add(path)
    for path in histories.iterdir():
        add(path)
    for directory in [ROOT/'instrumentation_test_seeded_control',ROOT/'instrumentation_test_diagnostic']:
        for name in ['conv.dat','picdata.bin','run.log','info.txt','particle_balance.csv']:
            if (directory/name).exists():
                add(directory/name)
    aliases = {ROOT.name+'_balance_summary.csv':'balance_summary.csv',
               ROOT.name+'_balance_summary.json':'balance_summary.json',
               ROOT.name+'.png':'extinction_diagnosis.png', ROOT.name+'.pdf':'extinction_diagnosis.pdf',
               ROOT.name+'_diagnostic.cc':'diagnostic.cc',ROOT.name+'_diagnostic.patch':'diagnostic.patch'}
    for alias, original in aliases.items():
        add(ROOT/original, alias)
    manifest = {'date_Asia_Seoul':'2026-11-20',
                'production_source_sha256':EXPECTED_SOURCE,
                'scope':'Five separate, five-RF transient branches; not steady-state results.',
                'files':{rel:{'size':path.stat().st_size,'sha256':sha(path.read_bytes())}
                         for rel,path in sorted(files.items())}}
    (ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    add(ROOT/'manifest.json')
    TARGET.mkdir(exist_ok=True)
    archive = TARGET/(ROOT.name+'_all.zip')
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for rel,path in sorted(files.items()):
            z.write(path, ROOT.name+'/'+rel)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for rel,record in manifest['files'].items():
            assert sha(z.read(ROOT.name+'/'+rel)) == record['sha256'],rel
    for alias,original in aliases.items():
        shutil.copy2(ROOT/original,TARGET/alias)
    shutil.copy2(ROOT/'README.md', TARGET/'README.md')
    shutil.copy2(ROOT/'manifest.json', TARGET/(ROOT.name+'_manifest.json'))
    published_files = sorted(p for p in TARGET.iterdir() if p.is_file() and p.suffix != '.sha256')
    (TARGET/(ROOT.name+'_checksums.sha256')).write_text(''.join(
        f'{sha(p.read_bytes())}  {p.name}\n' for p in published_files))
    print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,
                      'sha256':sha(archive.read_bytes()),'entries':len(files)},indent=2))

if __name__ == '__main__':
    main()
