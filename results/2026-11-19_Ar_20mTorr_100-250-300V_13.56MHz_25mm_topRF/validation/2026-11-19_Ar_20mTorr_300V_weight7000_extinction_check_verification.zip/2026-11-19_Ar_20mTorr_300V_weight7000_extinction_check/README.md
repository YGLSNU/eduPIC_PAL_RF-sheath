# 300 V particle-weight check

This supplementary check repeats the decay from RF cycle 250 at 20 mTorr and 300 V peak.
Every electron and ion macroparticle was copied ten times, with its position and all velocity components unchanged.
The particle weight was reduced from 70000 to 7000, preserving the initial physical densities, charge, velocity distributions and RF phase.

The production run first reached zero electrons at cycle 361. The refined realization first reached zero electrons at cycle 345 and stopped at cycle 350.
The refined check did not wait for the remaining ions to leave. Both runs extinguish, but their exact extinction times differ; this is one sensitivity check, not a complete numerical-convergence study or an experimental breakdown limit.

To repeat, use a separate directory. Copy input_cycle250.bin to picdata.bin, copy source-eduPIC.cc and run_check.py, then run:

```sh
g++ -std=c++11 -O3 -DEDUPIC_VOLTAGE_V=300.0 source-eduPIC.cc -o edupic
python run_check.py
```

The source in this check fixes particle weight at 7000. Do not use its checkpoint with the production weight of 70000.
The original code re-seeds its random generator on each invocation, so exact trajectories and extinction cycles will differ.
