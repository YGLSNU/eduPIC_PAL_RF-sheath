#!/usr/bin/env python3
"""Pool the accepted RF-phase measurements, matching the stopping estimator."""
from pathlib import Path
import json
import os
import numpy as np
os.environ.setdefault('MPLCONFIGDIR', '/tmp/edupic-matplotlib-40mm')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
LINEAR = ['pot', 'efield', 'ne', 'ni', 'je', 'ji', 'ioniz']

def pool(blocks):
    records = [json.loads((p/'block.json').read_text()) for p in blocks]
    counts = np.array([r['cycles_inclusive'][1]-r['cycles_inclusive'][0]+1 for r in records])
    assert len(counts) and np.all(counts == 20)
    sums = {key: np.zeros((640, 200)) for key in LINEAR}
    energy_sums = {s: np.zeros((640, 200)) for s in ['e', 'i']}
    for block, count in zip(blocks, counts):
        local = {key: np.loadtxt(block/(key+'_xt.dat')) for key in LINEAR}
        assert all(a.shape == (640, 200) and np.isfinite(a).all() for a in local.values())
        for key in LINEAR:
            sums[key] += count*local[key]
        for s in ['e', 'i']:
            energy = np.loadtxt(block/('meane'+s+'_xt.dat'))
            energy_sums[s] += count*local['n'+s]*energy
    means = {key: value/counts.sum() for key, value in sums.items()}
    for s in ['e', 'i']:
        # Native diagnostic and jackknife estimator both use pooled phase means.
        means['power'+s] = means['j'+s]*means['efield']
        means['meane'+s] = np.divide(energy_sums[s], sums['n'+s],
                                    out=np.zeros((640, 200)), where=sums['n'+s] > 0)
    assert all(np.isfinite(a).all() for a in means.values())
    return means, records, int(counts.sum())

def verify(means, assessment):
    x = np.linspace(0, .04, 640)
    checked = {}
    for s in ['e', 'i']:
        density = np.trapezoid(means['n'+s].mean(axis=1), x)/.04
        power = means['power'+s].mean()
        for key, value in [('mean_density_'+s, density), ('mean_power_'+s, power)]:
            expected = assessment['indicators'][key]['estimate']
            assert np.isclose(value, expected, rtol=2e-12, atol=1e-10), (key, value, expected)
            checked[key] = float(value)
    return checked

def export(case):
    state = json.loads((case/'status.json').read_text())
    if state['status'] != 'criteria_met':
        return None
    assessment = json.loads((case/'assessment.json').read_text())
    assert assessment['passed'] and state['consecutive_passes'] >= 2
    blocks = []
    for p in sorted((case/'blocks').glob('*/block.json')):
        r = json.loads(p.read_text())
        if r['phase'] == 'measurement' and r['measurement_epoch'] == state['measurement_epoch']:
            blocks.append(p.parent)
    means, records, cycles = pool(blocks)
    assert cycles == assessment['measurement_cycles'] == state['completed_measurement_cycles']
    checked = verify(means, assessment)
    output = case/'measurement_average'
    output.mkdir(exist_ok=True)
    x = np.linspace(0, .04, 640)
    phase = (np.arange(200)+.5)/200
    for key, value in means.items():
        np.savetxt(output/(key+'_xt.dat'), value, fmt='%.9e')
    np.savez_compressed(output/'phase_maps.npz', x_m=x, rf_phase_cycles=phase, **means)
    np.savetxt(output/'density.dat', np.column_stack([x, means['ne'].mean(axis=1), means['ni'].mean(axis=1)]), fmt='%.9e')
    profiles = np.column_stack([x]+[means[k].mean(axis=1) for k in ['ne', 'ni', 'powere', 'poweri', 'ioniz']])
    np.savetxt(output/'profiles.csv', profiles, delimiter=',',
               header='x_m,ne_m-3,ni_m-3,phase_mean_je_times_E_W_m-3,phase_mean_ji_times_E_W_m-3,ionization_m-3_s-1', comments='')
    details = {'voltage_peak_V': state['voltage_peak_V'], 'status': state['status'],
               'measurement_epoch': state['measurement_epoch'], 'measurement_cycles': cycles,
               'first_RF_cycle': records[0]['cycles_inclusive'][0],
               'last_RF_cycle': records[-1]['cycles_inclusive'][1],
               'blocks': [p.name for p in blocks], 'assessment_estimates_verified': checked,
               'power_definition': 'Pooled RF-phase mean j times pooled RF-phase mean E; not mean instantaneous jE.',
               'energy_definition': 'Density-weighted phase conditional mean particle energy in eV.',
               'orientation': 'x=0 lower grounded; x=0.04 m upper powered.',
               'array_order': '640 positions by 200 RF-phase bins; columns centered at (bin+0.5)/200.'}
    (output/'manifest.json').write_text(json.dumps(details, indent=2)+'\n')
    (output/'README.md').write_text(f'''# 수렴 판정에 사용한 전체 측정 구간 평균

{state['voltage_peak_V']} V peak, RF {details['first_RF_cycle']}–{details['last_RF_cycle']}, 총 {cycles} RF주기.
밀도·전류·전위·전기장·이온화율은 같은 위상 bin의 시간 평균이다. 평균 입자 에너지는 밀도로 가중했다.
powere/poweri는 전체 측정 구간의 위상 평균 j와 E를 곱한 값으로, 수렴 판정의 정의와 같다.
매 순간의 jE를 평균한 값이나 particle_balance.csv의 이산 입자 field-work와 구분해야 한다.

행은 위치 640점(0–40 mm), 열은 RF 위상 200개 bin이다. x=0 하부 접지, x=40 mm 상부 RF 전극.
phase_maps.npz에 정확한 위치와 위상 중심 좌표가 함께 들어 있다. 밀도 m^-3, 전위 V, 전기장 V/m,
전류밀도 A/m^2, heating W/m^3, 평균 에너지 eV, 이온화율 m^-3 s^-1이다.

EEPF와 IFED는 이 폴더에서 합성하지 않았다. 해당 분포는 원시 측정 블록과 last_diagnostic_block에 보존되어 있다.
''' )
    fig, axes = plt.subplots(2, 3, figsize=(13, 7), layout='constrained')
    fields = [('ne', 'Electron density', 'm$^{-3}$'), ('powere', 'Electron phase-mean heating', 'W m$^{-3}$'),
              ('ioniz', 'Ionization rate', 'm$^{-3}$ s$^{-1}$'), ('ni', 'Ion density', 'm$^{-3}$'),
              ('poweri', 'Ion phase-mean heating', 'W m$^{-3}$'), ('pot', 'Potential', 'V')]
    for ax, (key, title, unit) in zip(axes.flat, fields):
        kwargs = {}
        if key.startswith('power'):
            vmax = float(np.max(np.abs(means[key])))
            kwargs = {'cmap': 'RdBu_r', 'vmin': -vmax, 'vmax': vmax}
        mesh = ax.pcolormesh(phase, x*1000, means[key], shading='nearest', **kwargs)
        ax.set(title=title, xlabel='RF phase (cycles)', ylabel='Position (mm)', xlim=(0, 1), ylim=(0, 40))
        fig.colorbar(mesh, ax=ax, label=unit)
    fig.suptitle(f"Ar 20 mTorr | 40 mm | {state['voltage_peak_V']} V peak | RF {details['first_RF_cycle']}-{details['last_RF_cycle']}")
    fig.savefig(output/'phase_maps.png', dpi=170, bbox_inches='tight', pad_inches=.12)
    plt.close(fig)
    return output

def main():
    for case in sorted(ROOT.glob('*V')):
        if (case/'status.json').exists():
            export(case)

if __name__ == '__main__':
    main()
