#!/usr/bin/env python3
"""Report particle and energy balances per powered-electrode reference area."""
import csv,json,os
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import numpy as np
os.environ.setdefault('MPLCONFIGDIR','/tmp/edupic-matplotlib-40mm')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent

def collect():
    config=json.loads((ROOT/'config.json').read_text());result=[]
    for voltage in config['voltage_peak_V']:
        case=ROOT/f'{voltage}V'
        if not (case/'status.json').exists():continue
        status=json.loads((case/'status.json').read_text())
        rows=[]
        for p in sorted((case/'blocks').glob('*/block.json')):
            rows.extend(list(csv.DictReader((p.parent/'particle_balance.csv').open())))
        if status.get('active_cycles') and status['status']=='running':
            a,b=status['active_cycles'];p=case/'blocks'/f'cycle{a:06d}-{b:06d}'
            if not (p/'block.json').exists() and (p/'particle_balance.csv').exists():
                more=list(csv.DictReader((p/'particle_balance.csv').open()))
                rows.extend(x for x in more if None not in x.values())
        if not rows:continue
        # Final statistics use the accepted measurement epoch where available.
        if status['status']=='criteria_met':
            recent=[x for x in rows if int(x['RF_cycle'])>=status['measurement_start_cycle']]
            window='accepted measurement epoch'
        else:
            recent=rows[-min(50,len(rows)):];window='last up to 50 RF cycles; transient'
        sums=lambda k:sum(float(x[k]) for x in recent)
        duration=len(recent)/config['frequency_Hz'];A=config['fictive_area_m2'];W=config['weight'];gap=config['gap_m']
        births=sums('ionizations');le=sums('e_loss_lower')+sums('e_loss_upper');li=sums('i_loss_lower')+sums('i_loss_upper')
        record={'voltage_peak_V':voltage,'pressure_mTorr':20,'gap_mm':40,'status':status['status'],
                'latest_available_RF_cycle':int(rows[-1]['RF_cycle']),'last_checkpoint_cycle':status.get('checkpoint_cycle'),
                'electron_macroparticles':int(rows[-1]['end_e']),'ion_macroparticles':int(rows[-1]['end_i']),
                'electron_volume_mean_density_m3':int(rows[-1]['end_e'])*W/A/gap,
                'ion_volume_mean_density_m3':int(rows[-1]['end_i'])*W/A/gap,
                'balance_window':window,'balance_first_cycle':int(recent[0]['RF_cycle']),'balance_last_cycle':int(recent[-1]['RF_cycle']),
                'ionization_pairs':int(births),'electron_wall_losses':int(le),'ion_wall_losses':int(li),
                'electron_birth_loss_ratio':births/le if le else None,
                'electron_field_work_W_m2':sums('e_field_work_J')/duration/A,
                'ion_field_work_W_m2':sums('i_field_work_J')/duration/A,
                'electron_wall_kinetic_loss_W_m2':sums('e_wall_energy_J')/duration/A,
                'ion_wall_kinetic_loss_W_m2':sums('i_wall_energy_J')/duration/A,
                'excitation_ionization_threshold_loss_W_m2':(sums('excitations')*11.5+births*15.8)*1.60217662e-19*W/duration/A,
                'first_zero_electron_cycle':status.get('first_zero_electron_cycle'),
                'completed_measurement_cycles':status.get('completed_measurement_cycles',0),
                'accepted_measurement_cycles':status.get('completed_measurement_cycles',0) if status['status']=='criteria_met' else 0,
                'measured_time_volume_mean_electron_density_m3':None,
                'measured_time_volume_mean_ion_density_m3':None,
                'source_sha256':config['source_sha256']}
        if status['status']=='criteria_met':
            assessment=json.loads((case/'assessment.json').read_text())
            record['measured_time_volume_mean_electron_density_m3']=assessment['indicators']['mean_density_e']['estimate']
            record['measured_time_volume_mean_ion_density_m3']=assessment['indicators']['mean_density_i']['estimate']
        result.append(record)
    return result

def main():
    result=collect()
    (ROOT/'summary.json').write_text(json.dumps({'updated_at_Asia_Seoul':datetime.now(ZoneInfo('Asia/Seoul')).isoformat(),'cases':result},indent=2)+'\n')
    if result:
        with (ROOT/'summary.csv').open('w') as f:
            writer=csv.DictWriter(f,fieldnames=list(result[0]),lineterminator='\n');writer.writeheader();writer.writerows(result)
    fig,ax=plt.subplots(1,2,figsize=(11,4),layout='constrained')
    colors=['#4477aa','#ee9933','#aa3377','#228833','#bb4455']
    for rec,color in zip(result,colors):
        case=ROOT/f'{rec["voltage_peak_V"]}V'
        if not (case/'history.dat').exists():continue
        hist=np.loadtxt(case/'history.dat',ndmin=2)
        ax[0].plot(hist[:,0],hist[:,1]*112000/(1e-4*.04),label=f'{rec["voltage_peak_V"]} V',color=color)
        rows=list(csv.DictReader((case/'particle_balance.csv').open()))
        x=[];y=[]
        for start in range(0,len(rows),20):
            block=rows[start:start+20]
            if len(block)<20:continue
            B=sum(int(r['ionizations']) for r in block);D=sum(int(r['e_loss_lower'])+int(r['e_loss_upper']) for r in block)
            if D:x.append(int(block[-1]['RF_cycle']));y.append(B/D)
        ax[1].plot(x,y,label=f'{rec["voltage_peak_V"]} V',color=color)
    ax[0].set(xlabel='RF cycles after condition change',ylabel='Volume-mean electron density (m$^{-3}$)',title='40 mm, 20 mTorr: density evolution')
    ax[1].set(xlabel='RF cycles after condition change',ylabel='Ionization births / electron wall losses',title='Disjoint 20-RF event balances',ylim=(0,2))
    ax[1].axhline(1,color='black',ls='--',lw=1)
    for a in ax:a.legend(frameon=False);a.grid(alpha=.2)
    fig.savefig(ROOT/'comparison.png',dpi=170);fig.savefig(ROOT/'comparison.pdf');plt.close(fig)
    for r in result:
        print(f'{r["voltage_peak_V"]}V {r["status"]} RF={r["latest_available_RF_cycle"]} Ne={r["electron_macroparticles"]} B/L={r["electron_birth_loss_ratio"]:.3f}')

if __name__=='__main__':main()
