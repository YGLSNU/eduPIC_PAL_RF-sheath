#!/usr/bin/env python3
"""Checkpointed 40 mm scan with unaltered exploratory stopping tolerances."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from zoneinfo import ZoneInfo
import csv
import fcntl
import json
import os
import shutil
import subprocess
import time
import traceback
import numpy as np
from stopping import checkpoint, save_json, sha, stationarity, validate_block, assess_blocks

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT/'config.json').read_text())
CRITERIA = json.loads((ROOT/'criteria.json').read_text())

def now():
    return datetime.now(ZoneInfo('Asia/Seoul')).isoformat()

def atomic_copy(src, dst):
    dst = Path(dst); tmp = dst.with_suffix(dst.suffix+'.tmp')
    shutil.copy2(src,tmp); tmp.replace(dst)

def run_case(voltage):
    case = ROOT/f'{voltage}V'
    case.mkdir(exist_ok=True)
    with (case/'controller.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return _run_case(case,voltage)

def _run_case(case,voltage):
    state = json.loads((case/'status.json').read_text()) if (case/'status.json').exists() else {}
    if state.get('status') in ['criteria_met','extinguished','measurement_limit_reached','total_cycle_limit_reached']:
        return state
    def update(**kwargs):
        state.update(kwargs,updated_at_Asia_Seoul=now())
        save_json(case/'status.json',state)
    update(status='building',voltage_peak_V=voltage,pressure_mTorr=20,gap_mm=40,
           started_at_Asia_Seoul=state.get('started_at_Asia_Seoul',now()),controller_pid=os.getpid())
    try:
        assert sha(ROOT/'source-eduPIC.cc') == CONFIG['source_sha256']
        command=['g++','-std=c++11','-O3','-march=native',f'-DEDUPIC_VOLTAGE_V={voltage}.0',
                 str(ROOT/'source-eduPIC.cc'),'-o',str(case/'solver')]
        subprocess.run(command,check=True,capture_output=True,text=True)
        save_json(case/'build.json',{'command':command,'source_sha256':CONFIG['source_sha256'],'binary_sha256':sha(case/'solver')})
        previous=ROOT/'input_cycle0.bin'; history=[]; balances=[]; elapsed=0.; blocks=[]
        records=sorted((case/'blocks').glob('*/block.json'))
        for p in records:
            record=json.loads(p.read_text())
            assert record['input_checkpoint']['sha256']==sha(previous)
            previous=p.parent/'picdata.bin'
            assert record['output_checkpoint']['sha256']==sha(previous)
            history.extend(np.loadtxt(p.parent/'conv.dat',ndmin=2).tolist())
            balances.extend(list(csv.DictReader((p.parent/'particle_balance.csv').open())))
            elapsed+=record['wall_seconds']
        current=checkpoint(previous)
        phase=state.get('phase','warmup'); epoch=state.get('measurement_epoch',0)
        passes=state.get('consecutive_passes',0)
        for p in records:
            r=json.loads(p.read_text())
            if r['phase']=='measurement' and r['measurement_epoch']==epoch:blocks.append(p.parent)
        update(status='running',phase=phase,checkpoint_cycle=current['cycle'],measurement_epoch=epoch,
               electrons=current['electrons'],ions=current['ions'],elapsed_solver_seconds=elapsed)
        while True:
            if (ROOT/'STOP_AFTER_BLOCK').exists() or (case/'STOP_AFTER_BLOCK').exists():
                update(status='paused_at_checkpoint');break
            if current['electrons']==0:
                update(status='extinguished',first_zero_electron_cycle=current['cycle']);break
            if current['cycle']>=CRITERIA['maximum_total_cycles']:
                update(status='total_cycle_limit_reached');break
            stable=stationarity(history,CRITERIA)
            if phase=='warmup' and stable['passed']:
                phase='measurement';epoch+=1;blocks=[];passes=0
                update(phase=phase,measurement_epoch=epoch,measurement_start_cycle=current['cycle']+1)
            diagnostic=(phase=='measurement' or current['cycle']%100==0)
            count=CRITERIA['block_cycles'] if phase=='measurement' else (1 if diagnostic else min(50,100-current['cycle']%100))
            start=current['cycle']+1; end=current['cycle']+count
            work=case/'blocks'/f'cycle{start:06d}-{end:06d}'
            if work.exists():work.rename(work.with_name(work.name+'.interrupted.'+str(time.time_ns())))
            work.mkdir(parents=True)
            shutil.copy2(previous,work/'picdata.bin')
            atomic_copy(previous,case/'last_nonempty_checkpoint.bin')
            rng_seed=20261120+voltage*100000+start
            update(active_cycles=[start,end],phase=phase,particle_count_stationarity=stable)
            begin=time.monotonic()
            with (work/'run.log').open('w') as log:
                proc=subprocess.Popen(['stdbuf','-oL',str(case/'solver'),str(count)]+(['m'] if diagnostic else []),
                        cwd=work,stdout=log,stderr=subprocess.STDOUT,
                        env={**os.environ,'EDUPIC_DIAGNOSTIC_SEED':str(rng_seed)},start_new_session=True)
                update(solver_pid=proc.pid)
                code=proc.wait()
            if code:raise RuntimeError(f'Solver exit {code}; previous checkpoint preserved')
            elapsed+=time.monotonic()-begin
            output=checkpoint(work/'picdata.bin');actual=output['cycle']-current['cycle']
            assert 1<=actual<=count
            if actual<count:assert output['electrons']==0
            conv=np.loadtxt(work/'conv.dat',ndmin=2)
            assert conv.shape==(actual,3)
            assert np.array_equal(conv[:,0],np.arange(start,start+actual))
            rows=list(csv.DictReader((work/'particle_balance.csv').open()))
            assert len(rows)==actual
            for row in rows:
                for s in ('e','i'):
                    assert int(row[f'end_{s}'])-int(row[f'start_{s}'])==int(row['ionizations'])-int(row[f'{s}_loss_lower'])-int(row[f'{s}_loss_upper'])
            validation=None
            if diagnostic and output['electrons']>0:
                validation,_=validate_block(work,start,actual)
                pot=np.loadtxt(work/'pot_xt.dat')
                expected=voltage*np.cos(2*np.pi*(np.arange(4000)+1)/4000).reshape(200,20).mean(axis=1)
                assert np.max(abs(pot[0]))<1e-8
                assert np.allclose(pot[-1],expected,atol=.002,rtol=2e-6)
                save_json(work/'validation.json',validation)
            record={'cycles_inclusive':[start,output['cycle']],'requested_cycles':count,'phase':phase,
                    'measurement_epoch':epoch,'diagnostic_mode':diagnostic,'rng_seed':rng_seed,
                    'input_checkpoint':current,'output_checkpoint':output,'wall_seconds':time.monotonic()-begin,
                    'particle_balances_exact':True,'source_sha256':CONFIG['source_sha256'],'completed_at_Asia_Seoul':now()}
            save_json(work/'block.json',record)
            previous=work/'picdata.bin';current=output;history.extend(conv.tolist());balances.extend(rows)
            np.savetxt(case/'history.dat',history,fmt='%d')
            with (case/'particle_balance.csv').open('w') as f:
                writer=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');writer.writeheader();writer.writerows(balances)
            atomic_copy(previous,case/'latest_checkpoint.bin')
            recent=balances[-min(50,len(balances)):]
            births=sum(int(r['ionizations']) for r in recent)
            losses=sum(int(r['e_loss_lower'])+int(r['e_loss_upper']) for r in recent)
            state.pop('solver_pid',None)
            update(checkpoint_cycle=current['cycle'],elapsed_solver_seconds=elapsed,electrons=current['electrons'],ions=current['ions'],
                   recent_balance_cycles=len(recent),recent_ionizations=births,recent_e_wall_losses=losses,
                   recent_birth_loss_ratio=births/losses if losses else None,latest_block=str(work.relative_to(case)),
                   last_numerical_validation=validation or state.get('last_numerical_validation'))
            print(f'{now()} {voltage}V cycle={current["cycle"]} e={current["electrons"]} i={current["ions"]} B/L={births}/{losses} phase={phase}',flush=True)
            if current['electrons']==0:
                update(status='extinguished',first_zero_electron_cycle=current['cycle']);break
            if phase=='measurement':
                blocks.append(work)
                result=assess_blocks(blocks,history,CRITERIA)
                save_json(case/'assessment.json',result)
                with (case/'assessments.jsonl').open('a') as f:f.write(json.dumps({'cycle':current['cycle'],**result})+'\n')
                passes=passes+1 if result['passed'] else 0
                update(consecutive_passes=passes,completed_measurement_cycles=len(blocks)*20,particle_count_stationarity=result['particle_count_stationarity'])
                if passes>=CRITERIA['required_consecutive_passes']:
                    update(status='criteria_met');break
                drift=any(v['first_last_half_relative_change']>.03 for k,v in result.get('indicators',{}).items() if 'density' in k)
                if len(blocks)>=5 and drift and not result['particle_count_stationarity']['passed']:
                    phase='warmup';passes=0
                    update(phase=phase,consecutive_passes=0,epoch_discard_reason='renewed density drift')
                elif len(blocks)*20>=CRITERIA['maximum_measurement_cycles']:
                    update(status='measurement_limit_reached');break
        return state
    except Exception as exc:
        update(status='paused_error',error=str(exc))
        (case/'error.log').write_text(traceback.format_exc())
        print(f'{voltage}V ERROR {exc}',flush=True)
        return state

if __name__=='__main__':
    with ThreadPoolExecutor(max_workers=5) as pool:
        results=list(pool.map(run_case,CONFIG['voltage_peak_V']))
    save_json(ROOT/'scan_status.json',{'updated_at_Asia_Seoul':now(),'cases':results})
