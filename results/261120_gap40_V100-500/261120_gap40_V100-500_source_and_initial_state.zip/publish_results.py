#!/usr/bin/env python3
"""Publish completed, reviewable scan artifacts to the authorized results branch."""
from pathlib import Path
import csv,fcntl,hashlib,json,shutil,subprocess,sys,zipfile
from datetime import datetime
from zoneinfo import ZoneInfo
ROOT=Path(__file__).resolve().parent
UPLOAD=Path('/workspace/edupic-results-upload')
TARGET=UPLOAD/'results'/ROOT.name
BRANCH='results/2026-11-19-20mTorr-top-powered'
RAW='https://github.com/YGLSNU/eduPIC_PAL_RF-sheath/raw/refs/heads/'+BRANCH+'/results/'+ROOT.name+'/'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def archive(path,items):
    with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for file,relative in items:z.write(file,str(relative))
    with zipfile.ZipFile(path) as z:assert z.testzip() is None

def _publish_locked():
    if (ROOT/'published.json').exists():
        print('Completed report already published.');return
    states=[json.loads(p.read_text()) for p in sorted(ROOT.glob('*V/status.json'))]
    allowed={'criteria_met','extinguished','measurement_limit_reached','total_cycle_limit_reached'}
    assert len(states)==5 and all(s['status'] in allowed for s in states),'Only publish a completed scan; errors require review'
    subprocess.run([sys.executable,str(ROOT/'measurement_average.py')],cwd=ROOT,check=True)
    subprocess.run([sys.executable,str(ROOT/'summarize.py')],cwd=ROOT,check=True)
    records=json.loads((ROOT/'summary.json').read_text())['cases']
    TARGET.mkdir(exist_ok=True)
    for name in ['summary.csv','summary.json','comparison.png','comparison.pdf','AREA_REVIEW.md','config.json','criteria.json']:
        shutil.copy2(ROOT/name,TARGET/(ROOT.name+'_'+name))
    source_files=['source-eduPIC.cc','source-reference.cc','source-optical-depth.cc','run_scan40.py','run_scan40_reference.py',
                  'stopping.py','summarize.py','measurement_average.py','publish_results.py','config.json','criteria.json','input_cycle0.bin',
                  'LICENSE','AREA_REVIEW.md','software_versions.json','sampler_switch.json','validation/validation.json',
                  'validation/optical_depth/verification.json','validation/optical_depth/timings.json',
                  'validation/pooled_measurements.json']
    source_zip=TARGET/(ROOT.name+'_source_and_initial_state.zip')
    archive(source_zip,[(ROOT/n,Path(n)) for n in source_files if (ROOT/n).exists()])
    table=[];downloads=[]
    labels={'criteria_met':'통계 기준 만족','extinguished':'전자 소멸','measurement_limit_reached':'측정 상한 도달·기준 미충족',
            'total_cycle_limit_reached':'주기 상한 도달·기준 미충족'}
    for rec in sorted(records,key=lambda r:r['voltage_peak_V']):
        voltage=rec['voltage_peak_V'];case=ROOT/f'{voltage}V';state=json.loads((case/'status.json').read_text())
        key=f'2026-11-20_Ar_20mTorr_{voltage}V_13.56MHz_40mm_topRF'
        (case/'RESTART.md').write_text(f'''# 이어서 계산하기

이 조건: Ar 20 mTorr, gap 40 mm, {voltage} V peak, 13.56 MHz, 상부 RF/하부 접지.
소스 ZIP의 source-eduPIC.cc와 이 core ZIP의 latest_checkpoint.bin을 사용한다.
Linux에서 새 폴더에 복사하여 실행하는 예:

```bash
mkdir restart_{voltage}V
cp latest_checkpoint.bin restart_{voltage}V/picdata.bin
g++ -std=c++11 -O3 -march=native -DEDUPIC_VOLTAGE_V={voltage}.0 /path/to/source-eduPIC.cc -o restart_{voltage}V/solver
cd restart_{voltage}V
./solver 20 m
```

저장된 RF주기 이후 20주기를 추가 계산하고 새 입자 상태와 진단 파일을 저장한다.
원래 자료를 보존하기 위해 별도 폴더를 사용한다. 격자·gap·가중치·주파수를 임의로 바꾸지 않는다.
전자가 0인 상태에서는 현재 모델에 새 전자원이 없으므로 last_nonempty_checkpoint.bin 또는 공통 초기 상태를 사용해야 한다.
체크포인트에 난수 상태는 없어서 재시작 후 개별 확률 궤적은 달라진다.
이 예는 물리 상태의 재시작이며 과거 측정 통계나 자동 중단 제어기 이력을 이어 붙이는 명령은 아니다.
''')
        items=[]
        for name in ['RESTART.md','status.json','build.json','history.dat','particle_balance.csv','latest_checkpoint.bin','last_nonempty_checkpoint.bin','assessment.json','assessments.jsonl']:
            if (case/name).exists():items.append((case/name,Path(name)))
        complete=sorted((case/'blocks').glob('*/block.json'))
        diagnostics=[p.parent for p in complete if (p.parent/'info.txt').exists()]
        if diagnostics:
            for p in diagnostics[-1].iterdir():
                if p.is_file() and p.name!='picdata.bin':items.append((p,Path('last_diagnostic_block')/p.name))
        for p in complete:items.append((p,Path('block_records')/p.parent.name/'block.json'))
        if state['status']=='criteria_met':
            for p in sorted((case/'measurement_average').iterdir()):
                if p.is_file():items.append((p,Path('measurement_average')/p.name))
            shutil.copy2(case/'measurement_average/phase_maps.png',TARGET/(key+'_phase_maps.png'))
        core=TARGET/(key+'_core.zip');archive(core,items)
        assert core.stat().st_size<95*1024*1024
        average_link=f' · [측정 전체 평균 그림]({key}_phase_maps.png)' if state['status']=='criteria_met' else ''
        downloads.append(f'| {voltage} V | [요약·체크포인트·진단 자료]({RAW}{core.name}){average_link} |')
        # Preserve the complete accepted measurement epoch in bounded-size ZIP parts.
        accepted=[p.parent for p in complete if (r:=json.loads(p.read_text()))['phase']=='measurement'
                  and r['measurement_epoch']==state.get('measurement_epoch')]
        parts=[];part_items=[];uncompressed=0
        for block in accepted:
            for p in sorted(block.iterdir()):
                if not p.is_file() or p.name=='picdata.bin':continue
                if part_items and uncompressed+p.stat().st_size>75*1024*1024:
                    part=TARGET/(key+f'_measurements_part{len(parts)+1:02d}.zip');archive(part,part_items)
                    parts.append(part);part_items=[];uncompressed=0
                part_items.append((p,Path(block.name)/p.name));uncompressed+=p.stat().st_size
        if part_items:
            part=TARGET/(key+f'_measurements_part{len(parts)+1:02d}.zip');archive(part,part_items);parts.append(part)
        for i,p in enumerate(parts,1):downloads.append(f'| {voltage} V 측정 {i}/{len(parts)} | [원시 측정 블록]({RAW}{p.name}) |')
        ratio=rec['electron_birth_loss_ratio'];ratio_text='—' if ratio is None else f'{ratio:.3f}'
        density=rec['measured_time_volume_mean_electron_density_m3'];density_text='—' if density is None else f'{density:.3e}'
        table.append(f'| {voltage} | {labels[rec["status"]]} | {rec["latest_available_RF_cycle"]} | {density_text} | {ratio_text} | {rec["accepted_measurement_cycles"]} |')
    report=f'''# Ar 20 mTorr, gap 40 mm: 전압 비교 결과

실행 시작일: 2026-11-20 (한국 시각). 결과 정리: {datetime.now(ZoneInfo('Asia/Seoul')).isoformat()}.

상부 정현파 전압, 하부 접지. 전압은 **peak**이다. Ar 350 K, 13.56 MHz, 전극 간격 40 mm.

| V peak | 판정 | 마지막 RF주기 | 측정 평균 전자 밀도 m⁻³ | 생성/전자 벽 손실 | 기준 통과 측정 RF주기 |
|---:|---|---:|---:|---:|---:|
{chr(10).join(table)}

밀도는 기준을 통과한 전체 측정 구간의 공간·시간 평균이다. 생성/손실은 통계 기준 만족 조건에서 최종 측정 구간 전체, 그 외 조건에서는 마지막 최대 50주기를 사용한다. 서로 다른 시점의 일시적인 비율만으로 전압 효과를 정량 비교하면 안 된다. 전자 소멸은 정상상태 수렴이 아니다. 측정/주기 상한으로 끝난 조건은 기준을 충족한 것으로 표기하지 않았다.

![입자 밀도와 생성·손실](./{ROOT.name}_comparison.png)

- [수치 요약 CSV]({ROOT.name}_summary.csv)
- [면적·지름·전력 수지 검토]({ROOT.name}_AREA_REVIEW.md)
- [실행 소스·조건·공통 초기 상태 ZIP]({RAW}{source_zip.name})

| 조건 | 다운로드 |
|---|---|
{chr(10).join(downloads)}

기준을 통과한 조건의 core ZIP에는 **measurement_average/** 폴더가 있다. 해당 폴더는 수렴 판정에 사용한 전체 측정 구간의 밀도·RF 위상별 heating·전위·이온화율을 제공한다. last_diagnostic_block/은 마지막 한 블록만의 자료이다. heating은 전체 측정 구간의 위상 평균 j × 위상 평균 E로 계산했으며, stopping.py의 추정값과 일치하는지 확인했다.

## 해석과 수치 조건

현재 1D 평판 모델은 면적당 거동을 계산한다. 같은 flux와 입자 에너지에서 총 벽 손실 전력은 면적에 비례한다. 같은 전압과 동일한 단위면적 상태에서 공통 면적을 키우면 공급 전력·입자 수·체적도 함께 증가한다. 따라서 이상적인 동일 면적 평판에서는 공통 면적이 밀도 수지에서 상쇄된다. 총 W 고정, 전극 면적비, 유한 지름·측벽 효과를 비교하려면 실제 면적 및 외부 회로/적절한 기하 모델이 필요하다. 이 계산에 독립적인 전극 지름이나 A_eff는 없다.

요약 CSV의 전력은 **W/m²**이며 양 전극의 손실을 합해 한쪽 공통 면적으로 나눴다. field-work는 입자 속도 갱신에서의 전기장의 일이고, 발생기 표시 전력이나 과도상태의 단자 VI 전력과 동일시하지 않는다. 실제 전극 면적이 없어 실험의 총 W로 환산하지 않았다.

격자 640점, 전자 시간간격 RF/4000, 이온 subcycle 20. dx=62.598 µm로 기존 25 mm 계산의 공간 해상도를 유지했다. 초기 입자 위치를 1.6배 늘리고 계산 입자 가중치를 70,000→112,000으로 조정해 같은 x/L에서 물리 밀도와 속도 분포를 보존했다. 초기 상태 자체가 40 mm에서 정상상태인 것은 아니므로 과도상태는 측정에서 제외했다. 이번에는 가중치와 체적을 같은 비율로 늘려 계산 입자 수와 체적 평균 밀도의 비례계수 W/(A*L)가 두 gap에서 동일하다. 결과 CSV와 그림에는 물리 밀도를 표시했다.

전자 MCC는 체크포인트 이후 잔여 광학깊이 Exp(1) 샘플링을 사용한다. 매 시간간격의 충돌 확률 1−exp(−νΔt)와 1회 충돌 제한은 유지하며 난수 궤적은 달라진다. 기존 방법과 4개 난수 seed×5주기 비교 및 기존 방법 비활성화 분기의 바이트 일치 검증 기록을 소스 ZIP에 포함했다. 이온 MCC와 표면 흡수·충돌 단면적·물리 모델은 동일하다. 초기 참조 방법과 이후 방법의 소스 해시 및 전환 체크포인트는 config와 각 block record에 기록했다.

수렴 기준: 최근 600 RF주기의 입자 수를 200주기씩 나눈 평균 차이 <1%, 선형 drift <2%. 이후 최소 100주기 측정, 20주기 블록에서 평균량·밀도 3%, 40×40 heating map 5% 기준을 연속 2회 만족하면 종료한다. 통계적 중단 기준이며 전체 물리/수치 오차 보증은 아니다. 모든 측정 블록의 기본 안정성 및 입자 생성·손실 수지를 확인한다. 기존 phase heating 출력은 평균 전류×평균 전기장 정의를 유지했다.

빈 체크포인트는 현재 전자원 없는 모델에서 방전을 재생하지 못한다. 소멸한 조건은 last_nonempty_checkpoint.bin 또는 공통 초기 상태로 재시작해야 한다. 체크포인트에는 난수 상태가 없으며 재시작 seed는 블록 기록에 남긴다. 초기 및 과도상태의 모든 원시 체크포인트는 클라우드 실행 디렉터리에 보존했다.
'''
    (TARGET/'README.md').write_text(report)
    manifest={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(TARGET.iterdir()) if p.is_file() and not p.name.endswith('_manifest.json')}
    (TARGET/(ROOT.name+'_manifest.json')).write_text(json.dumps(manifest,indent=2)+'\n')
    index=UPLOAD/'results/README.md';line=f'- [2026-11-20: 20 mTorr·40 mm·100–500 V 비교]({ROOT.name}/README.md)\n'
    if line not in index.read_text():index.write_text(index.read_text().rstrip()+'\n'+line)
    subprocess.run(['git','add','results/README.md',str(TARGET.relative_to(UPLOAD))],cwd=UPLOAD,check=True)
    subprocess.run(['git','commit','-m','Publish 40 mm voltage scan and electrode-area power review'],cwd=UPLOAD,check=True)
    subprocess.run(['git','push','origin','HEAD:refs/heads/'+BRANCH],cwd=UPLOAD,check=True)
    (ROOT/'published.json').write_text(json.dumps({'directory':str(TARGET),'branch':BRANCH,'completed_at_Asia_Seoul':datetime.now(ZoneInfo('Asia/Seoul')).isoformat()},indent=2)+'\n')

def main():
    with (ROOT/'publish.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        _publish_locked()

if __name__=='__main__':main()
