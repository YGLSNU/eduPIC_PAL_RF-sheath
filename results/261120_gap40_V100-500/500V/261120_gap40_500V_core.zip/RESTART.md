# 이어서 계산하기

이 조건: Ar 20 mTorr, gap 40 mm, 500 V peak, 13.56 MHz, 상부 RF/하부 접지.
소스 ZIP의 source-eduPIC.cc와 이 core ZIP의 latest_checkpoint.bin을 사용한다.
Linux에서 새 폴더에 복사하여 실행하는 예:

```bash
mkdir restart_500V
cp latest_checkpoint.bin restart_500V/picdata.bin
g++ -std=c++11 -O3 -march=native -DEDUPIC_VOLTAGE_V=500.0 /path/to/source-eduPIC.cc -o restart_500V/solver
cd restart_500V
./solver 20 m
```

저장된 RF주기 이후 20주기를 추가 계산하고 새 입자 상태와 진단 파일을 저장한다.
원래 자료를 보존하기 위해 별도 폴더를 사용한다. 격자·gap·가중치·주파수를 임의로 바꾸지 않는다.
전자가 0인 상태에서는 현재 모델에 새 전자원이 없으므로 last_nonempty_checkpoint.bin 또는 공통 초기 상태를 사용해야 한다.
체크포인트에 난수 상태는 없어서 재시작 후 개별 확률 궤적은 달라진다.
이 예는 물리 상태의 재시작이며 과거 측정 통계나 자동 중단 제어기 이력을 이어 붙이는 명령은 아니다.
