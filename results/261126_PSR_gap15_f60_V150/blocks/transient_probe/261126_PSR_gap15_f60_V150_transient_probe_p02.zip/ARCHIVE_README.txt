PSR/VI raw diagnostic payloads. RF range and sampling definitions: block.json and psr_metadata.json.
Download ALL 4 ZIP(s) and extract them into the same directory.
Files with .partNNNN are lossless byte parts; run: python reassemble_psr.py
The script verifies every original payload SHA256. CSV.gz and NPZ remain compressed data files.
Stationary measurement blocks and explicitly labelled transient pilot copies are separate.
Terminal/sheath time series and phase-folded fields cover exactly the block listed in block.json.
