BRH raw diagnostic payloads. RF range and sampling definitions: summary.json.
Download ALL 1 ZIP(s) and extract them into the same directory.
Files with .partNNNN are lossless byte parts; run: python reassemble_brh.py
The script verifies every original payload SHA256. CSV.gz and NPZ remain compressed data files.
Trajectory illustration covers only the first five RF of the first measurement block.
Round-trip/encounter events, probes, energy histograms and field work cover the recorded measurement epoch.
