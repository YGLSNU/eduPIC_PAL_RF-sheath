"""Finish export automatically after the long simulation, even between chat turns."""
from pathlib import Path
from datetime import datetime, timezone
import json
import subprocess
import time

root = Path(__file__).resolve().parent
while True:
    state = json.loads((root/'progress.json').read_text())
    if state['stage'] == 'failed':
        raise SystemExit('Simulation failed: '+state.get('error', 'see progress.json'))
    if state['stage'] == 'simulation_complete':
        with (root/'analysis.log').open('w') as log:
            result = subprocess.run(['python3', str(root/'analyze.py')], cwd=root,
                                    stdout=log, stderr=subprocess.STDOUT)
        (root/'export-status.json').write_text(json.dumps({
            'completed_utc': datetime.now(timezone.utc).isoformat(),
            'exit_code': result.returncode,
            'status': 'complete' if result.returncode == 0 else 'failed',
            'log': 'analysis.log'}, indent=2)+'\n')
        raise SystemExit(result.returncode)
    time.sleep(30)
