# Historical run records

This run is incomplete and is not running. progress.json is a historical record. picdata.bin contains cycle 1700. conv.dat has complete rows through cycle 2406 and a truncated trailing line. Keep these originals unchanged; use a separate folder for any restart.
