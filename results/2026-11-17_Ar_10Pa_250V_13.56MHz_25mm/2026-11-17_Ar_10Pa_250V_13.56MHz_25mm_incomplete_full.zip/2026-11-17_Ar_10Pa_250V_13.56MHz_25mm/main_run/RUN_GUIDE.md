# 기본 조건 계산을 확인하는 방법

이 폴더는 YGLSNU/eduPIC_PAL_RF-sheath의 원본 C/eduPIC.cc를 실행한 결과를 저장합니다.
기본 물리 조건: Ar, 10 Pa, 350 K, 전압 진폭 250 V, 13.56 MHz, 전극 간격 25 mm.

## 현재 진행 상태

[progress.json](progress.json)을 열어 확인합니다.

- `stage: convergence`: 정상상태에 도달하기 위한 계산 중입니다.
- `active_cycle`: 현재 계산 중인 누적 RF주기입니다.
- `checkpoint_cycle`: 디스크에 안전하게 저장된 마지막 RF주기입니다.
- `stage: measurement`: 수렴 판정 후 1000 RF주기의 측정 중입니다.
- `stage: simulation_complete`: 계산 완료입니다. 후처리 결과는 export-status.json에서 확인합니다.
- `export-status.json`의 `status: complete`: 검증·그래프·CSV·ZIP 생성도 완료됐습니다.
- `stage: failed` 또는 후처리의 `status: failed`: 로그 검토가 필요한 상태입니다.

수렴은 최소 1500 RF주기를 계산한 뒤 최근 600주기의 입자 수 기록으로 판정합니다.
최근 600주기를 세 개의 200주기 구간으로 나누고 전자·이온 각각의 평균 차이가 1% 미만,
600주기에 걸친 선형 추세 변화가 2% 미만이면 측정 단계로 넘어갑니다.

## 완료 후 볼 파일

아래 파일은 장시간 측정과 후처리가 끝난 뒤 생성됩니다.

1. `report.html`: 웹브라우저로 열 수 있는 그림과 설명을 포함한 보고서.
2. `plots/overview.png` 또는 `plots/overview.pdf`: 결과를 요약한 6개 그래프.
3. `plots/phase_resolved.png`: RF 위상에 따른 밀도·이온화·가열 분포.
4. `RESULTS.md`: 실행 범위, 실제 수치, 검증 결과, 파일별 의미.
5. `info.txt`: 시뮬레이터가 작성한 설정·안정성·플럭스·흡수 전력 보고서.
6. `csv/`: Excel에서 열 수 있는 변환 데이터.
7. 상위 폴더의 `eduPIC-default-results.zip`: 원본 수치 데이터와 그림·CSV·체크포인트·소스·로그 묶음.

`density.dat`의 세 열은 위치(m), 전자 밀도(m⁻³), 이온 밀도(m⁻³)입니다.
`pot_xt.dat` 등 XT 파일은 400개 위치 × 200개 RF 위상 구간 행렬입니다.
`picdata.bin`은 같은 물리 조건에서 계산을 이어갈 수 있는 입자 데이터이며 일반 표 형식 파일이 아닙니다.

## GitHub와 이 환경의 역할

GitHub에 보관된 소스를 이 클라우드 컴퓨터에서 컴파일·실행합니다.
생성되는 데이터는 이 결과 폴더에 있으며 GitHub에 자동으로 업로드되지 않습니다.
이번 작업은 원본 저장소 소스의 수정, 커밋, 푸시 또는 환경 게시를 하지 않습니다.
결과 보관·공유에는 완료 후 생성된 ZIP을 사용하면 됩니다.

원본 eduPIC은 Donko 등 저자들의 GPLv3 소프트웨어입니다.
연구에 사용할 때는 원본 코드에 명시된 논문을 인용하세요:
Z. Donko et al., Plasma Sources Science and Technology 30, 095017 (2021).
