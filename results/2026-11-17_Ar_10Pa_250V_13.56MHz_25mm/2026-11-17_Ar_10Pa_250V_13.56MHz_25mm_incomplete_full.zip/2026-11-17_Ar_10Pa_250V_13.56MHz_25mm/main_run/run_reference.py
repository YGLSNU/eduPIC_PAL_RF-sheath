"""Run the unchanged C implementation, retaining restart points and progress."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import shutil
import struct
import subprocess
import time

import numpy as np

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/workspace/eduPIC_PAL_RF-sheath/C/eduPIC.cc')
BIN = ROOT / 'edupic-native'
STATE = {'stage': 'starting', 'updated_utc': None}
START = time.monotonic()


def save_json(path, data):
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, indent=2) + '\n')
    tmp.replace(path)


def progress(**values):
    STATE.update(values)
    STATE['updated_utc'] = datetime.now(timezone.utc).isoformat()
    STATE['runner_elapsed_seconds'] = time.monotonic() - START
    save_json(ROOT / 'progress.json', STATE)


def checkpoint_cycles():
    with (ROOT / 'picdata.bin').open('rb') as f:
        sim_time, cycles, ne = struct.unpack('ddd', f.read(24))
        assert cycles.is_integer() and 0 < ne < 1_000_000
        f.seek(int(ne) * 32, 1)
        ni = struct.unpack('d', f.read(8))[0]
    assert (ROOT / 'picdata.bin').stat().st_size == 32 + 32 * (ne + ni)
    assert abs(sim_time - cycles / 13.56e6) < 1e-10
    return int(cycles)


def convergence(cycles):
    data = np.loadtxt(ROOT / 'conv.dat', ndmin=2)
    assert data.shape[0] == cycles
    assert np.array_equal(data[:, 0], np.arange(1, cycles + 1))
    assert np.all(data[:, 1:3] > 0)
    if cycles < 600:
        return {'passed': False, 'reason': 'fewer than 600 cycles'}
    tail = data[-600:, 1:3]
    blocks = tail.reshape(3, 200, 2).mean(axis=1)
    relative_span = np.ptp(blocks, axis=0) / blocks.mean(axis=0)
    fitted_drift = abs(np.polyfit(np.arange(600), tail, 1)[0]) * 599 / tail.mean(axis=0)
    return {'passed': bool(cycles >= 1500 and np.all(relative_span < .01) and np.all(fitted_drift < .02)),
            'cycles': cycles, 'window_cycles': 600, 'block_cycles': 200,
            'electron_ion_block_means': blocks.tolist(),
            'relative_block_span': relative_span.tolist(),
            'relative_fitted_drift': fitted_drift.tolist(),
            'criteria': 'At least 1500 cycles; three 200-cycle means span <1%, fitted 600-cycle drift <2%, for both species.'}


def segment(n, measure=False):
    before = checkpoint_cycles()
    stage = 'measurement' if measure else 'convergence'
    destination = before + n
    archive = ROOT / 'checkpoints' / f'cycle-{before:05d}.bin'
    if not archive.exists():
        shutil.copy2(ROOT / 'picdata.bin', archive)
    progress(stage=stage, segment_start_cycle=before,
             segment_target_cycle=destination, checkpoint_cycle=before)
    args = [str(BIN), str(n)] + (['m'] if measure else [])
    log_path = ROOT / 'logs' / f'{stage}-{before+1:05d}-{destination:05d}.log'
    t0 = time.monotonic()
    with log_path.open('w') as log:
        p = subprocess.Popen(['stdbuf', '-oL', *args], cwd=ROOT,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             text=True, bufsize=1)
        progress(child_pid=p.pid)
        for line in p.stdout:
            log.write(line)
            log.flush()
            m = re.search(r'c =\s*(\d+)\s+t =\s*(\d+)\s+#e =\s*(\d+)\s+#i =\s*(\d+)', line)
            if m:
                c, step, ne, ni = map(int, m.groups())
                fraction = c - before - 1 + step / 4000
                elapsed = time.monotonic() - t0
                progress(active_cycle=c, step=step, electrons=ne, ions=ni,
                         segment_elapsed_seconds=elapsed,
                         average_seconds_per_cycle=elapsed / fraction if fraction > 0 else None)
        code = p.wait()
    if code != 0:
        raise RuntimeError(f'{args} failed with exit code {code}; see {log_path}')
    done = checkpoint_cycles()
    assert done == destination, (done, destination)
    check = convergence(done)
    event = {'stage': stage, 'args': args, 'cycles_before': before, 'cycles_after': done,
             'wall_seconds': time.monotonic() - t0, 'convergence': check,
             'completed_utc': datetime.now(timezone.utc).isoformat()}
    with (ROOT / 'segments.jsonl').open('a') as f:
        f.write(json.dumps(event) + '\n')
    progress(checkpoint_cycle=done, convergence=check)
    print(f'{stage}: checkpoint {done}, {event["wall_seconds"]:.1f} seconds, stationarity={check["passed"]}', flush=True)
    return check


def main():
    (ROOT / 'checkpoints').mkdir(exist_ok=True)
    (ROOT / 'logs').mkdir(exist_ok=True)
    assert SOURCE.read_bytes() == (ROOT / 'source-eduPIC.cc').read_bytes(), 'Original source differs'
    save_json(ROOT / 'reference-plan.json', {
        'source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        'binary_sha256': hashlib.sha256(BIN.read_bytes()).hexdigest(),
        'compile_command': 'g++ -std=c++11 -O3 -march=native C/eduPIC.cc -o edupic-native',
        'min_convergence_cycles': 1500, 'measurement_cycles': 1000,
        'max_convergence_cycles_before_review': 4000,
        'physical_parameters': 'Unchanged upstream defaults',
        'randomness': 'Upstream random_device seeding; restart does not serialize RNG state.'})
    done = checkpoint_cycles()
    check = convergence(done)
    while not check['passed']:
        if done >= 4000:
            raise RuntimeError('Stationarity criteria still unmet at 4000 cycles; needs review before measurement.')
        n = min(100, (1500 - done) if done < 1500 else 100)
        check = segment(n)
        done = checkpoint_cycles()
    save_json(ROOT / 'convergence-before-measurement.json', check)
    progress(measurement_start_cycle=done, measurement_cycles=1000)
    segment(1000, measure=True)
    report = (ROOT / 'info.txt').read_text()
    if 'VIOLATED' in report:
        raise RuntimeError('Built-in numerical stability check failed; see info.txt')
    progress(stage='simulation_complete', child_pid=None)
    print('SIMULATION COMPLETE; diagnostics are ready for validation and plotting.', flush=True)


if __name__ == '__main__':
    try:
        main()
    except BaseException as exc:
        progress(stage='failed', error=str(exc))
        raise
