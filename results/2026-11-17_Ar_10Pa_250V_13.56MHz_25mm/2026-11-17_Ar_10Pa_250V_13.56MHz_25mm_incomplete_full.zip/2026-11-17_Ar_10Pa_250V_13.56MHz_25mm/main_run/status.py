"""Display the current saved status of this run."""
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
state = json.loads((root / 'progress.json').read_text())

def count(value):
    return f'{value:,}' if isinstance(value, int) else '?'

phase = state['stage']
measurement = ''
if phase in ['measurement', 'simulation_complete']:
    completed = (state.get('active_cycle', 0) - state.get('measurement_start_cycle', 0) - 1)
    if phase == 'simulation_complete':
        completed = state['measurement_cycles']
    measurement = f" | 측정 완료 {max(0, completed)}/{state.get('measurement_cycles', 1000)}주기"
print(f"진행: {phase} | RF주기 {state.get('active_cycle', '?')}"
      f" | 전자 {count(state.get('electrons'))} / 이온 {count(state.get('ions'))}"
      f" | 저장된 주기 {state.get('checkpoint_cycle', '?')}"
      f" | 경과 {state['runner_elapsed_seconds']/60:.1f}분{measurement}")
if '--details' in sys.argv:
    check = state.get('convergence', {})
    print(json.dumps({'evaluated_cycle': check.get('cycles'),
                     'block_mean_span_percent': [round(100*x, 3) for x in check.get('relative_block_span', [])],
                     'trend_percent': [round(100*x, 3) for x in check.get('relative_fitted_drift', [])]}, ensure_ascii=False))
if state.get('error'):
    print(state['error'])
