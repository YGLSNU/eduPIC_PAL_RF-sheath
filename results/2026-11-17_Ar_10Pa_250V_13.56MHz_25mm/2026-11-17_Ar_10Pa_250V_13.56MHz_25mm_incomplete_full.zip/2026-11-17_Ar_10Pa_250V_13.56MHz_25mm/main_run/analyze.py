"""Validate a completed original-code run and export plots, CSVs, and a report."""
from pathlib import Path
import base64
import hashlib
import html
import json
import os
import re
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent
os.environ['MPLCONFIGDIR'] = str(ROOT / '.mpl-cache')
os.environ['XDG_CACHE_HOME'] = str(ROOT / '.cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams.update({'figure.dpi': 150, 'font.size': 10, 'axes.spines.top': False,
                     'axes.spines.right': False, 'axes.grid': True, 'grid.alpha': .18,
                     'savefig.facecolor': 'white', 'axes.prop_cycle':
                     plt.cycler(color=['#2467ad', '#d05228', '#2a9179'])})


def main():
    state = json.loads((ROOT / 'progress.json').read_text())
    assert state['stage'] == 'simulation_complete', 'Wait for simulation completion'
    before = json.loads((ROOT / 'convergence-before-measurement.json').read_text())
    assert before['passed']
    start = before['cycles']
    report = (ROOT / 'info.txt').read_text()
    assert 'VIOLATED' not in report
    assert re.search(r'cycles in this run\s*=\s*1000\b', report)
    specs = {'conv': (start+1000, 3), 'density': (400, 3), 'eepf': (2000, 2), 'ifed': (200, 3)}
    xt_names = ['pot', 'efield', 'ne', 'ni', 'je', 'ji', 'powere', 'poweri', 'meanee', 'meanei', 'ioniz']
    specs.update({name+'_xt': (400, 200) for name in xt_names})
    arrays = {}
    for name, shape in specs.items():
        arr = np.loadtxt(ROOT / (name + '.dat'))
        assert arr.shape == shape, (name, arr.shape, shape)
        assert np.all(np.isfinite(arr)), f'{name}: nonfinite values'
        arrays[name] = arr
    conv, density, eepf, ifed = [arrays[n] for n in ['conv', 'density', 'eepf', 'ifed']]
    assert np.array_equal(conv[:, 0], np.arange(1, start+1001))
    assert np.all(conv[:, 1:] > 0)
    assert np.all(density[:, 1:] >= 0)
    assert np.allclose(density[:, 0], np.linspace(0, .025, 400), atol=1e-8)
    eepf_norm = float(np.sum(eepf[:, 1] * np.sqrt(eepf[:, 0])) * .05)
    ifed_norm = ifed[:, 1:].sum(axis=0)
    assert abs(eepf_norm - 1) < 1e-5, eepf_norm
    assert np.all(abs(ifed_norm - 1) < 2e-4), ifed_norm
    phase = (np.arange(200)[:, None] * 20 + np.arange(1, 21)[None, :]) / 4000
    expected_voltage = 250 * np.cos(2*np.pi*phase).mean(axis=1)
    voltage_error = float(np.max(abs(arrays['pot_xt'][0] - expected_voltage)))
    assert voltage_error < .02, voltage_error
    assert np.all(abs(arrays['pot_xt'][-1]) < 1e-9)
    assert np.allclose(arrays['ne_xt'].mean(axis=1), density[:, 1], rtol=2e-6, atol=1)
    assert np.allclose(arrays['ni_xt'].mean(axis=1), density[:, 2], rtol=2e-6, atol=1)
    cfl_energy = float(re.search(r'Max e- energy for CFL condition\s*=\s*([\d.eE+-]+)', report)[1])
    tail_eepf = float(eepf[eepf[:, 0] >= cfl_energy, 1].max())
    tail_mass = float(np.sum(eepf[eepf[:, 0] >= cfl_energy, 1] *
                             np.sqrt(eepf[eepf[:, 0] >= cfl_energy, 0])) * .05)
    segments = [json.loads(line) for line in (ROOT / 'segments.jsonl').read_text().splitlines()]
    initial = json.loads((ROOT / 'run-metadata.json').read_text())
    elapsed = sum(x['wall_seconds'] for x in segments) + sum(x['wall_seconds'] for x in initial['segments'])
    metrics = {'all_output_arrays_finite': True, 'completed_cycles': start+1000,
               'convergence_cycles': start, 'measurement_cycles': 1000,
               'measured_RF_cycles_inclusive': [start+1, start+1000],
               'simulated_time_us': (start+1000)/13.56,
               'measurement_time_us': 1000/13.56,
               'compute_wall_seconds': elapsed,
               'center_electron_density_m-3': float(density[200, 1]),
               'center_ion_density_m-3': float(density[200, 2]),
               'final_superparticles_electron_ion': conv[-1, 1:].astype(int).tolist(),
               'mean_ion_energy_powered_ground_eV': (ifed[:, :1]*ifed[:, 1:]).sum(axis=0).tolist(),
               'eepf_normalization': eepf_norm, 'ifed_normalizations': ifed_norm.tolist(),
               'max_powered_boundary_voltage_error_V': voltage_error,
               'cfl_energy_eV': cfl_energy, 'max_eepf_at_or_above_cfl_eV-3/2': tail_eepf,
               'center_electron_fraction_above_cfl': tail_mass,
               'manual_center_eepf_tail_check_passed': tail_eepf <= 1e-6,
               'post_measurement_particle_stationarity': segments[-1]['convergence']}
    (ROOT / 'validation.json').write_text(json.dumps(metrics, indent=2)+'\n')
    plotdir, csvdir = ROOT/'plots', ROOT/'csv'
    plotdir.mkdir(exist_ok=True)
    csvdir.mkdir(exist_ok=True)
    csv_headers = {'conv': 'rf_cycle,electron_superparticles,ion_superparticles',
                   'density': 'position_m,electron_density_m-3,ion_density_m-3',
                   'eepf': 'energy_eV,eepf_eV-3_per_2',
                   'ifed': 'energy_eV,powered_IFEDF_eV-1,grounded_IFEDF_eV-1'}
    for name, header in csv_headers.items():
        np.savetxt(csvdir/(name+'.csv'), arrays[name], delimiter=',', header=header, comments='')
    for name in xt_names:
        np.savetxt(csvdir/(name+'_xt.csv'), np.column_stack([density[:, 0], arrays[name+'_xt']]),
                   delimiter=',', header='position_m,'+','.join(f'phase_bin_{i:03d}' for i in range(200)), comments='')
    np.savetxt(csvdir/'phase_coordinates.csv', np.column_stack([np.arange(200),
               np.arange(200)/200, (np.arange(200)+1)/200, (np.arange(200)*20+10.5)/4000]),
               delimiter=',', header='phase_bin,start_t_over_T,end_t_over_T,sample_mean_t_over_T', comments='')

    def convergence_plot(ax):
        ax.plot(conv[:, 0], conv[:, 1], label='Electrons')
        ax.plot(conv[:, 0], conv[:, 2], label='Ar+ ions')
        ax.axvspan(start, start+1000, alpha=.1, color='#2a9179', label='Measurement (1000 cycles)')
        ax.set(xlabel='RF cycle', ylabel='Number of superparticles', title='Particle-number convergence')
        ax.ticklabel_format(axis='y', style='sci', scilimits=(0,0))
        ax.legend(fontsize=8)

    def density_plot(ax):
        ax.plot(density[:, 0]*1000, density[:, 1], label='Electrons')
        ax.plot(density[:, 0]*1000, density[:, 2], label='Ar+ ions')
        ax.set(xlabel='Position x (mm)', ylabel='Density (m$^{-3}$)', title='Time-averaged density')
        ax.legend(fontsize=8)

    def energy_plot(ax):
        good = eepf[:, 1] > 0
        ax.semilogy(eepf[good, 0], eepf[good, 1])
        ax.axvline(cfl_energy, color='#d05228', ls='--', lw=1, label=f'CFL energy: {cfl_energy:.1f} eV')
        ax.axhline(1e-6, color='gray', lw=.6, ls=':')
        ax.set(xlabel='Electron energy (eV)', ylabel='EEPF (eV$^{-3/2}$)', title='Central 10% electron energy distribution', xlim=(0, max(cfl_energy+5, 40)))
        ax.legend(fontsize=8)

    def ifed_plot(ax):
        ax.plot(ifed[:, 0], ifed[:, 1], label='Powered electrode')
        ax.plot(ifed[:, 0], ifed[:, 2], label='Grounded electrode')
        ax.set(xlabel='Ion energy (eV)', ylabel='IFEDF (eV$^{-1}$)', title='Ion flux energy distribution')
        ax.legend(fontsize=8)

    def heatmap(ax, name, title, unit, scale=1, cmap='viridis'):
        arr = arrays[name+'_xt']/scale
        kwargs = {}
        if cmap == 'RdBu_r':
            limit = np.max(abs(arr))
            kwargs = {'vmin': -limit, 'vmax': limit}
        im = ax.imshow(arr, origin='lower', aspect='auto', interpolation='nearest',
                       extent=[0, 1, 0, 25], cmap=cmap, **kwargs)
        ax.grid(False)
        ax.set(xlabel='RF phase t/T', ylabel='Position x (mm)', title=title)
        ax.figure.colorbar(im, ax=ax, label=unit, fraction=.046, pad=.03)

    fig, axes = plt.subplots(2, 3, figsize=(15, 8.6), layout='constrained')
    convergence_plot(axes[0, 0])
    density_plot(axes[0, 1])
    heatmap(axes[0, 2], 'pot', 'RF phase-resolved potential', 'V', cmap='RdBu_r')
    energy_plot(axes[1, 0])
    ifed_plot(axes[1, 1])
    heatmap(axes[1, 2], 'efield', 'RF phase-resolved electric field', 'kV/m', scale=1000, cmap='RdBu_r')
    fig.suptitle(f'eduPIC original C code | Ar 10 Pa, 250 V, 13.56 MHz, 25 mm\n'
                 f'{start} convergence cycles + 1000 measurement cycles', fontsize=15)
    fig.savefig(plotdir/'overview.png')
    fig.savefig(plotdir/'overview.pdf')
    plt.close(fig)
    fig, axes = plt.subplots(2, 2, figsize=(11, 8), layout='constrained')
    heatmap(axes[0,0], 'ne', 'Electron density', '10$^{15}$ m$^{-3}$', scale=1e15)
    heatmap(axes[0,1], 'ni', 'Ion density', '10$^{15}$ m$^{-3}$', scale=1e15)
    heatmap(axes[1,0], 'ioniz', 'Ionization rate', 'm$^{-3}$ s$^{-1}$')
    heatmap(axes[1,1], 'powere', 'Electron power absorption', 'kW/m$^3$', scale=1000, cmap='RdBu_r')
    fig.savefig(plotdir/'phase_resolved.png')
    fig.savefig(plotdir/'phase_resolved.pdf')
    plt.close(fig)
    for name, fun in [('convergence',convergence_plot), ('density',density_plot), ('eepf',energy_plot), ('ifed',ifed_plot)]:
        fig, ax = plt.subplots(figsize=(8,5), layout='constrained')
        fun(ax)
        fig.savefig(plotdir/(name+'.png'))
        plt.close(fig)

    status_tail = '통과' if metrics['manual_center_eepf_tail_check_passed'] else '추가 검토 필요'
    status_stationary = '통과' if metrics['post_measurement_particle_stationarity']['passed'] else '추가 검토 필요'
    text = f'''# eduPIC 기본 조건 실행 결과

GitHub 저장소의 원본 C/eduPIC.cc를 수정 없이 컴파일하여 이 클라우드 컴퓨터에서 계산했습니다.
GitHub는 소스 보관 장소이고 계산과 결과 파일 생성은 클라우드에서 수행됩니다.
저장소 커밋: {initial['commit']}

## 실행 조건과 범위

- Ar 10 Pa, 350 K, 전압 진폭 250 V, 주파수 13.56 MHz, 전극 간격 25 mm
- 공간 격자 400점, RF주기당 4000시간 간격, 입자 가중치 70000
- 초기 전자·이온 각각 1000개, 원본 난수 초기화 방식 사용
- 수렴 계산 {start} RF주기, 측정 계산 1000 RF주기 (누적 {start+1}–{start+1000}주기)
- 실제 모사한 시간 {(start+1000)/13.56:.3f} µs, 측정 시간 {1000/13.56:.3f} µs
- 계산 소요 시간 약 {elapsed/3600:.2f}시간 (컴파일·후처리 시간 제외)

수렴 판정은 최소 1500주기 후 최근 600주기를 200주기씩 나눈 세 구간의 평균 입자 수가
전자·이온 모두 1% 범위 안에 들고, 600주기 선형 추세 변화가 2% 미만인지를 확인했습니다.
입자 수의 정상상태 판정이며 모든 물리량에 대한 엄밀한 수렴 증명을 뜻하지 않습니다.
원본 코드는 매 실행 시 난수를 새로 초기화하므로 재실행한 값은 조금씩 달라집니다.

## 결과를 보는 순서

1. plots/overview.png 또는 plots/overview.pdf: 수렴, 밀도, 전위, 전기장, 에너지 분포를 한눈에 확인합니다.
2. plots/convergence.png: 전자·이온 입자 수가 평탄해졌는지 봅니다. 초록 영역이 측정 구간입니다.
3. plots/density.png: 전극 근처 전자 밀도 감소와 이온 밀도 차이로 sheath 영역을 살펴봅니다.
4. plots/phase_resolved.png: RF 위상에 따라 달라지는 밀도·이온화·전자 가열 분포를 확인합니다.
5. info.txt: 원본 코드가 작성한 설정, 안정성 조건, 이온 에너지, 전극 입자 플럭스, 흡수 전력을 확인합니다.
6. csv/ 폴더: Excel에서 CSV 파일을 열어 직접 그래프를 만들 수 있습니다.

## 주요 수치와 검증

- 중심 부근 전자 밀도: {density[200,1]:.6e} m⁻³
- 중심 부근 이온 밀도: {density[200,2]:.6e} m⁻³
- 전원/접지 전극 평균 이온 에너지: {metrics['mean_ion_energy_powered_ground_eV'][0]:.3f} / {metrics['mean_ion_energy_powered_ground_eV'][1]:.3f} eV
- 모든 결과 배열의 크기와 유한한 수치 확인: 통과
- 원본 코드의 4개 안정성·정확도 조건: 통과 (info.txt 참조)
- EEPF와 두 IFEDF의 적분 정규화, 전극 전위 경계, 시간평균 밀도 일치: 통과
- 매뉴얼의 중심 EEPF 기준 CFL 꼬리 점검: {status_tail}, 기준 에너지 {cfl_energy:.3f} eV
- 측정 종료 시 최근 600주기의 입자 수 정상성: {status_stationary}

전체 검증 수치는 validation.json에 있습니다. 중심 EEPF 검사는 전체 시공간 에너지 분포를 대체하지 않습니다.

## 원본 결과 파일

| 파일 | 열 또는 배열의 의미 |
|---|---|
| conv.dat | RF주기, 전자 슈퍼입자 수, 이온 슈퍼입자 수 |
| density.dat | 위치(m), 전자 밀도(m⁻³), 이온 밀도(m⁻³) |
| eepf.dat | 에너지(eV), 중심 10% 영역 EEPF(eV⁻³ᐟ²) |
| ifed.dat | 에너지(eV), 전원 전극 IFEDF, 접지 전극 IFEDF (eV⁻¹) |
| pot_xt.dat | 전위(V), 400×200 행렬 |
| efield_xt.dat | 전기장(V/m), 400×200 행렬 |
| ne_xt.dat / ni_xt.dat | 전자/이온 밀도(m⁻³) |
| je_xt.dat / ji_xt.dat | 전자/이온 전류 밀도(A/m²) |
| powere_xt.dat / poweri_xt.dat | 전자/이온 전력 밀도(W/m³) |
| meanee_xt.dat / meanei_xt.dat | 평균 전자/이온 에너지(eV) |
| ioniz_xt.dat | 이온화율(m⁻³ s⁻¹) |
| picdata.bin | 다음 계산을 이어가는 최종 입자 체크포인트 |

XT 행렬은 행이 x=0…25 mm 공간 격자이고 열이 한 RF주기의 200개 위상 구간입니다.
그림에서 x=0은 전원 전극, x=25 mm는 접지 전극입니다.
CSV 변환본의 첫 열은 위치이며 phase_coordinates.csv에 위상 좌표가 있습니다.
모든 측정 파일은 지정한 1000주기에 걸쳐 평균 또는 정규화한 결과입니다.
저장소에 포함된 ReferenceCase_RawData는 저자 제공 예제이며, 이 폴더의 새 계산과 별개입니다.

## 재현 및 이어서 실행

원본 소스 사본 source-eduPIC.cc와 실행 로그, 실행 메타데이터를 함께 보관했습니다.
컴파일 명령: g++ -std=c++11 -O3 -march=native source-eduPIC.cc -o edupic-native
첫 계산: 빈 결과 디렉터리에서 실행 파일에 0을 전달합니다.
이어 계산: 같은 디렉터리에서 실행 파일에 원하는 추가 RF주기 수를 전달합니다.
측정 계산: 추가 RF주기 수 뒤에 m을 붙입니다. 예: ./edupic-native 1000 m
측정 명령은 기존 진단 파일을 덮어쓰므로 별도 폴더로 체크포인트와 실행 파일을 복사한 뒤 실행하세요.
결과 데이터는 GitHub에 자동으로 올라가지 않으며 이 실행에서 커밋·푸시·환경 게시는 하지 않았습니다.
'''
    (ROOT/'RESULTS.md').write_text(text)
    image_tags = []
    for filename in ['overview.png', 'phase_resolved.png']:
        data = base64.b64encode((plotdir/filename).read_bytes()).decode()
        image_tags.append(f'<img alt="{filename}" src="data:image/png;base64,{data}">')
    style = '''body{font:16px/1.7 sans-serif;max-width:1200px;margin:32px auto;padding:16px;color:#172b3a}
        img{width:100%;height:auto}h1{line-height:1.3}h2{margin-top:36px}a{color:#1c5e9d}
        table{width:100%;border-collapse:collapse;margin:20px 0}td,th{text-align:left;padding:10px 14px;border-bottom:1px solid #dce3e9}
        th{width:40%;background:#f3f6f9}.links{display:flex;gap:12px;flex-wrap:wrap}.links a{padding:8px 14px;background:#edf4fa;border-radius:6px;text-decoration:none}
        .note{background:#f3f6f9;padding:16px 20px;border-left:4px solid #2467ad}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:14px/1.7 sans-serif}
        details{margin-top:32px;padding:16px 20px;border:1px solid #dce3e9;border-radius:6px}summary{cursor:pointer;font-weight:bold}
        footer{font-size:13px;color:#536574;margin-top:32px;overflow-wrap:anywhere}'''
    summary_rows = [
        ('계산 범위', f'수렴 {start:,} RF주기 + 측정 1,000 RF주기'),
        ('측정한 누적 주기', f'{start+1:,}–{start+1000:,}주기'),
        ('계산 소요 시간', f'약 {elapsed/3600:.2f}시간'),
        ('중심 부근 전자 밀도', f'{density[200,1]:.4e} m⁻³'),
        ('중심 부근 이온 밀도', f'{density[200,2]:.4e} m⁻³'),
        ('평균 이온 에너지 (전원 / 접지)',
         f'{metrics["mean_ion_energy_powered_ground_eV"][0]:.2f} / {metrics["mean_ion_energy_powered_ground_eV"][1]:.2f} eV'),
        ('코드의 4개 안정성·정확도 조건', '통과'),
        ('중심 EEPF의 CFL 꼬리 검사', status_tail),
        ('측정 종료 시 입자 수 정상성 검사', status_stationary)]
    summary_table = '<table>'+''.join('<tr><th>'+html.escape(label)+'</th><td>'+html.escape(value)+'</td></tr>'
                                    for label,value in summary_rows)+'</table>'
    (ROOT/'report.html').write_text('<!doctype html><html lang="ko"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1">'
        '<title>eduPIC 기본 조건 계산 결과</title><style>'+style+'</style></head><body>'
        '<h1>eduPIC 기본 조건 계산 결과</h1>'
        '<p>원본 C/eduPIC.cc를 수정 없이 실행했습니다. Ar 10 Pa · 350 K · 전압 진폭 250 V · 13.56 MHz · 전극 간격 25 mm.</p>'
        +summary_table+
        '<div class="links"><a href="plots/overview.pdf">그림 PDF</a><a href="csv/density.csv">밀도 CSV</a>'
        '<a href="csv/eepf.csv">전자 에너지 CSV</a><a href="csv/ifed.csv">이온 에너지 CSV</a><a href="info.txt">코드 출력 보고서</a></div>'
        '<h2>결과를 보는 순서</h2><p>수렴 곡선의 초록 영역은 측정 구간입니다. 밀도 그래프에서는 전극 근처의 전자·이온 밀도 차이를 보고, '
        '전위·전기장 지도에서는 RF 위상에 따른 sheath 변화를 살펴보세요. x=0은 전원 전극, x=25 mm는 접지 전극입니다.</p>'
        +image_tags[0]+
        '<h2>RF 위상에 따른 분포</h2><p>아래 지도는 전자·이온 밀도, 이온화율, 전자 전력 흡수의 1,000주기 측정 결과입니다. '
        '가로축은 한 RF주기의 위상, 세로축은 전극 사이의 위치입니다.</p>'+image_tags[1]+
        '<p class="note">CSV는 Excel에서 열 수 있습니다. density.csv의 세 열은 위치(m), 전자 밀도(m⁻³), 이온 밀도(m⁻³)입니다. '
        'XT 파일은 400개 위치 × 200개 RF 위상 구간이며, 모든 원본 수치 데이터와 변환 CSV를 함께 보관했습니다.</p>'
        '<details><summary>상세 실행 기록·검증 기준·파일별 설명</summary><pre>'+html.escape(text)+'</pre></details>'
        '<footer>GitHub는 소스 보관 장소이며 이 계산과 데이터 생성은 클라우드 환경에서 수행했습니다. '
        '코드 버전: '+html.escape(initial['commit'])+'<br>원본 eduPIC: Z. Donko et al., Plasma Sources Science and Technology 30, 095017 (2021). '
        'GPLv3 라이선스와 원본 매뉴얼을 결과 묶음에 포함했습니다.</footer></body></html>')
    checksums = {}
    for f in sorted(ROOT.glob('*.dat')):
        checksums[f.name] = hashlib.sha256(f.read_bytes()).hexdigest()
    checksums['source-eduPIC.cc'] = hashlib.sha256((ROOT/'source-eduPIC.cc').read_bytes()).hexdigest()
    (ROOT/'checksums.json').write_text(json.dumps(checksums, indent=2)+'\n')
    shutil.copy2('/workspace/eduPIC_PAL_RF-sheath/LICENSE', ROOT/'LICENSE')
    shutil.copy2('/workspace/eduPIC_PAL_RF-sheath/C/eduPIC_manual.pdf', ROOT/'eduPIC_manual.pdf')
    archive = ROOT.parent/'eduPIC-default-results.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in sorted(ROOT.iterdir()):
            if path.is_file() and (path.name == 'LICENSE' or path.suffix in ['.dat','.txt','.md','.html','.json','.jsonl','.py','.cc','.bin','.pdf']):
                z.write(path, ROOT.name+'/'+path.name)
        for folder in ['plots', 'csv', 'logs']:
            for path in sorted((ROOT/folder).rglob('*')):
                if path.is_file(): z.write(path, ROOT.name+'/'+str(path.relative_to(ROOT)))
    print(json.dumps(metrics, indent=2))
    print(f'REPORT: {ROOT / "report.html"}')
    print(f'ARCHIVE: {archive} ({archive.stat().st_size} bytes)')


if __name__ == '__main__':
    main()
