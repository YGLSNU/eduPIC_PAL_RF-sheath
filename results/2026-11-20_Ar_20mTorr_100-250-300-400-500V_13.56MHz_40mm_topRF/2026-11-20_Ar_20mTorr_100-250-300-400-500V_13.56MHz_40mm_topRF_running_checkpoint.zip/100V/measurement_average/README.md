# 수렴 판정에 사용한 전체 측정 구간 평균

100 V peak, RF 2001–2700, 총 700 RF주기.
밀도·전류·전위·전기장·이온화율은 같은 위상 bin의 시간 평균이다. 평균 입자 에너지는 밀도로 가중했다.
powere/poweri는 전체 측정 구간의 위상 평균 j와 E를 곱한 값으로, 수렴 판정의 정의와 같다.
매 순간의 jE를 평균한 값이나 particle_balance.csv의 이산 입자 field-work와 구분해야 한다.

행은 위치 640점(0–40 mm), 열은 RF 위상 200개 bin이다. x=0 하부 접지, x=40 mm 상부 RF 전극.
phase_maps.npz에 정확한 위치와 위상 중심 좌표가 함께 들어 있다. 밀도 m^-3, 전위 V, 전기장 V/m,
전류밀도 A/m^2, heating W/m^3, 평균 에너지 eV, 이온화율 m^-3 s^-1이다.

EEPF와 IFED는 이 폴더에서 합성하지 않았다. 해당 분포는 원시 측정 블록과 last_diagnostic_block에 보존되어 있다.
