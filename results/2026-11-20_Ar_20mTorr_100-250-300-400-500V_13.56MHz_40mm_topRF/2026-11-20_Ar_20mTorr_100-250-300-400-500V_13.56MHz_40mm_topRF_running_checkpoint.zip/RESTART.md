# 진행 중인 물리 상태의 체크포인트
전체 전압 비교가 진행 중인 시점의 상태 백업입니다. snapshot_manifest.json의 조건별 상태·저장 시점·RF주기를 확인하세요.
각 전압 폴더의 picdata.bin은 그 조건을 이어서 계산할 수 있는 입자 상태입니다.
예: g++ -std=c++11 -O3 -march=native -DEDUPIC_VOLTAGE_V=500.0 source-eduPIC.cc -o solver
500V 폴더에서 ../solver 20 m 를 실행하면 저장 주기 이후20주기를 계산합니다.
처음에는 별도 작업 폴더에 복사하여 실행하고, gap/가중치/주파수 등은 config.json과 같게 유지하세요.
기존 난수 상태는 체크포인트에 없으므로 확률 궤적은 달라집니다.
이 ZIP은 물리 상태 재시작용이며 전체 제어기의 과거 블록 디렉터리를 포함하지 않습니다.
이미 기준을 충족한 조건에는 measurement_average/와 assessment.json 등 완료 자료도 포함되어 있습니다.
