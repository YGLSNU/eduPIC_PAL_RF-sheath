"""Extract every ZIP into one directory, then run this script there."""
from pathlib import Path
import hashlib,json,shutil
root=Path(__file__).resolve().parent
manifest=json.loads((root/'payload_manifest.json').read_text())
for name,m in manifest['files'].items():
    if Path(name).name!=name:raise SystemExit('Invalid payload name')
    parts=[root/p['path'] for p in m['parts']]
    if any(not p.exists() for p in parts):raise SystemExit('Extract all ZIP parts first: '+name)
    destination=root/name
    if not (len(parts)==1 and parts[0]==destination):
        temp=destination.with_name(destination.name+'.joining')
        with temp.open('wb') as out:
            for part in parts:
                with part.open('rb') as src:shutil.copyfileobj(src,out)
        temp.replace(destination)
    h=hashlib.sha256()
    with destination.open('rb') as src:
        for chunk in iter(lambda:src.read(1024*1024),b''):h.update(chunk)
    if h.hexdigest()!=m['sha256'] or destination.stat().st_size!=m['bytes']:raise SystemExit('Checksum mismatch: '+name)
    print('Verified',name)
print('All payload files restored. CSV.gz and NPZ files are ready to read.')
