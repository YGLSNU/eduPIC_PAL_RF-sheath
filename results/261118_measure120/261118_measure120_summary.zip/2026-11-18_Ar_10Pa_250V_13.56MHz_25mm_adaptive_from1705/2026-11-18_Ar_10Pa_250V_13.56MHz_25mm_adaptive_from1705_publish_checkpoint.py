"""Back up completed measurement blocks to the user's existing GitHub result branch."""
from pathlib import Path
import json
import shutil
import subprocess
import zipfile
from adaptive_common import ROOT, KEY, sha, save_json, complete_blocks, checkpoint

UPLOAD = Path('/workspace/edupic-results-upload')
DEST = UPLOAD/'results'/KEY
BRANCH = 'results/2026-11-17-default-incomplete'
REPO = 'https://github.com/YGLSNU/eduPIC_PAL_RF-sheath'
RAW = f'{REPO}/raw/refs/heads/{BRANCH}/results/{KEY}/'

def archive(path, entries):
    if path.exists():
        return
    temp = path.with_suffix('.zip.tmp')
    with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for source, member in entries:
            z.write(source, member)
    with zipfile.ZipFile(temp) as z:
        assert z.testzip() is None
    assert temp.stat().st_size < 95_000_000, 'Split archives before GitHub 100 MB file limit'
    temp.replace(path)

def publish():
    DEST.mkdir(parents=True, exist_ok=True)
    assert subprocess.check_output(['git','branch','--show-current'], cwd=UPLOAD, text=True).strip() == BRANCH
    state = json.loads((ROOT/'status.json').read_text())
    status_label = {'running':'계산 중', 'criteria_met':'통계 기준 만족·계산 종료',
                    'measurement_limit_reached':'측정 상한 도달·기준 재검토 필요',
                    'paused_at_checkpoint':'체크포인트 저장 후 일시 중단'}.get(state['status'],state['status'])
    for name in ['criteria.json','provenance.json','status.json','adaptive_common.py','run_adaptive.py','publish_checkpoint.py','analyze_adaptive.py','finalize_results.py','RESUME.md']:
        if (ROOT/name).exists():
            shutil.copyfile(ROOT/name, DEST/(KEY+'_'+name))
    for name in ['assessment.json','assessments.jsonl']:
        if (ROOT/name).exists():
            shutil.copyfile(ROOT/name, DEST/(KEY+'_'+name))
    entries = [(ROOT/'input-cycle1705.bin', KEY+'/picdata.bin'),
               (ROOT/'source-eduPIC.cc', KEY+'/source-eduPIC.cc'),
               (ROOT/'provenance.json',KEY+'/provenance.json'),
               (ROOT/'RESUME.md',KEY+'/RESUME.md'),
               (ROOT/'LICENSE',KEY+'/LICENSE')]
    archive(DEST/(KEY+'_input_cycle1705_restart.zip'), entries)
    blocks = complete_blocks()
    inventory = []
    for p in blocks:
        meta = json.loads((p/'block.json').read_text())
        filename = KEY+'_'+p.name+'.zip'
        archive(DEST/filename, [(q,KEY+'/blocks/'+p.name+'/'+q.name) for q in sorted(p.iterdir()) if q.is_file()])
        inventory.append(dict(file=filename, bytes=(DEST/filename).stat().st_size, sha256=sha(DEST/filename),
                              cycles=meta['cycles_inclusive'], checkpoint=meta['output_checkpoint']))
    manifest = dict(status=state, blocks=inventory, input_checkpoint=checkpoint(ROOT/'input-cycle1705.bin'))
    save_json(DEST/(KEY+'_manifest.json'), manifest)
    latest = inventory[-1] if inventory else None
    if state['status'] in ['criteria_met','measurement_limit_reached','paused_at_checkpoint'] and blocks:
        from finalize_results import finalize
        finalize(DEST)
    rows = '\n'.join(f"| {q['cycles'][0]}–{q['cycles'][1]} | {q['bytes']/1e6:.2f} MB | [원본 결과·체크포인트 ZIP]({RAW}{q['file']}) |" for q in inventory)
    report_link = '\n[최종 보고서·그림](FINAL_REPORT.md)\n' if (DEST/'FINAL_REPORT.md').exists() else ''
    text = f'''# 2026-11-18: 통계 기준에 따른 추가 측정

원본 C/eduPIC.cc, Ar 10 Pa, 350 K, 전압 진폭 250 V, 13.56 MHz, 전극 간격 25 mm.
1,705주기 체크포인트에서 재개했으며, 원본 시뮬레이션 소스와 물리 조건은 바꾸지 않았습니다.

**마지막 업로드 상태: {status_label} / 저장 완료 {state['checkpoint_cycle']:,}주기 / 새 측정 {len(blocks)*20}주기.**
이는 업로드 당시 상태입니다. 브라우저 화면은 실시간 CPU 실행 상태를 나타내지 않습니다.
{report_link}
## 중단 기준

20주기씩 저장하고 최소 100주기부터 검사합니다. 다음을 두 번 연속 만족하면 자동 종료합니다.

- 전자·이온 평균/중심 밀도와 평균 전력: 블록 통계의 예상 불확실성 지표 및 전후반 변화 각각 3% 이내.
- 전자·이온 밀도 공간분포: 같은 지표를 분포 전체 L2 norm으로 정규화해 3% 이내.
- 전자·이온 heating 맵: 공간 40 × 위상 40으로 평균한 맵 전체의 L2 기준 5% 이내.
- 최근 600주기 입자 수: 200주기씩 세 평균의 범위 1% 미만, 선형 변화량 2% 미만.

Student-t 배수의 블록 표준오차에 양의 시간상관 보정을 사용합니다. 200주기 이상이면 40주기 단위 재집계도 비교합니다.
이는 대략적인 결과 취합용 중단 규칙이며 정확한 참값 대비 오차, 모든 픽셀의 5% 오차, 엄밀한 순차적 95% 신뢰수준을 보장하지 않습니다.
원본 400 × 200 맵은 모두 보관합니다. 최대 1,000주기 추가 측정 시 재평가를 위해 멈추며, 기준 미달 상태를 수렴으로 표기하지 않습니다.

## 구간별 원본과 재시작 파일

| 새 측정 RF주기 | 크기 | 다운로드 |
|---|---|---|
{rows}

각 ZIP에는 해당 구간의 15개 DAT, info.txt, 로그, 검사 기록 및 마지막 picdata.bin이 있습니다.
{'현재 마지막 재시작 상태는 '+str(latest['checkpoint']['cycle'])+'주기입니다.' if latest else '첫 구간 계산 전에는 1,705주기 상태를 사용할 수 있습니다.'}

- [시작 1,705주기 체크포인트·원본 소스]({RAW}{KEY}_input_cycle1705_restart.zip)
- [재시작 방법]({KEY}_RESUME.md)
- [중단 기준 설정]({KEY}_criteria.json)
- [검사 수치]({KEY}_assessment.json)
- [파일 목록·체크섬]({KEY}_manifest.json)

강제 종료 시 마지막으로 완전히 저장된 구간까지만 재개할 수 있습니다. 원본 코드는 난수 상태를 저장하지 않습니다.
중간 재시작으로 개별 궤적은 달라질 수 있으나 같은 조건의 통계적 연속 계산은 가능합니다.
원본 진단 누적값은 재시작 때 초기화되므로 이전 결과를 보관하고 후처리로 결합해야 합니다.
'''
    (DEST/'README.md').write_text(text)
    index = UPLOAD/'results/README.md'
    content = index.read_text()
    row = f'| 2026-11-18 | Ar 10 Pa, 전압 진폭 250 V, 13.56 MHz, 전극 간격 25 mm | 추가 측정: {status_label}, {state["checkpoint_cycle"]}주기까지 보관 | [결과 폴더]({KEY}/) |'
    lines = [line for line in content.splitlines() if KEY+'/' not in line]
    insert = max(i for i,line in enumerate(lines) if line.startswith('|'))+1
    lines.insert(insert,row)
    index.write_text('\n'.join(lines)+'\n')
    subprocess.run(['git','add','--','results/'+KEY,'results/README.md'],cwd=UPLOAD,check=True)
    changed = subprocess.run(['git','diff','--cached','--quiet'],cwd=UPLOAD).returncode
    if changed:
        subprocess.run(['git','commit','-m',f'Preserve adaptive measurement through RF cycle {state["checkpoint_cycle"]} ({state["status"]})'],cwd=UPLOAD,check=True)
    subprocess.run(['git','push','origin','HEAD:refs/heads/'+BRANCH],cwd=UPLOAD,check=True,timeout=180)
    head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=UPLOAD,text=True).strip()
    save_json(ROOT/'last-github-backup.json', dict(commit=head, checkpoint_cycle=state['checkpoint_cycle'], status=state['status']))
    print(f'GITHUB_BACKUP {head} checkpoint={state["checkpoint_cycle"]}',flush=True)

if __name__ == '__main__':
    publish()
